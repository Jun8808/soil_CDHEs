clear all
clc

gpp_ano_detrend_compsite = ncread('H:\WORKS\34-Soil_CDHE\figure1\fig1ab.nc','gpp_ano_detrend_compsite');
gpp_ano_detrend_compsite(find(gpp_ano_detrend_compsite==-999)) = NaN;
comp_extrm_frq_ens1 = ncread('H:\WORKS\34-Soil_CDHE\figure5\historical_ssp126.nc','comp_extrm_frq');
comp_extrm_frq_ens2 = ncread('H:\WORKS\34-Soil_CDHE\figure5\historical_ssp245.nc','comp_extrm_frq');
comp_extrm_frq_ens3 = ncread('H:\WORKS\34-Soil_CDHE\figure5\historical_ssp585.nc','comp_extrm_frq');

lon = ncread('H:\WORKS\34-Soil_CDHE\figure5\historical_ssp126.nc','lon');
lat = ncread('H:\WORKS\34-Soil_CDHE\figure5\historical_ssp126.nc','lat');

areas = zeros(length(lon),length(lat));

radis = 6.371*10^6;
delta_lon = 0.5*pi/180.0;

for j = 1:length(lat)
    for i = 1:length(lon)
    areas(i,j) = radis^2*delta_lon*(sin(pi*(lat(j)+0.25)/180.0)-sin(pi*(lat(j)-0.25)/180.0));
    end
end

gpp_ano_ens1 = comp_extrm_frq_ens1.*repmat(gpp_ano_detrend_compsite,[1 1 121 50]).*repmat(areas,[1 1 121 50]);
gpp_ano_ens2 = comp_extrm_frq_ens2.*repmat(gpp_ano_detrend_compsite,[1 1 121 50]).*repmat(areas,[1 1 121 50]);
gpp_ano_ens3 = comp_extrm_frq_ens3.*repmat(gpp_ano_detrend_compsite,[1 1 121 50]).*repmat(areas,[1 1 121 50]);

gpp_ano_ens1 = reshape(gpp_ano_ens1,[size(gpp_ano_ens1,1)*size(gpp_ano_ens1,2) size(gpp_ano_ens1,3) size(gpp_ano_ens1,4)]);
gpp_ano_ens2 = reshape(gpp_ano_ens2,[size(gpp_ano_ens2,1)*size(gpp_ano_ens2,2) size(gpp_ano_ens2,3) size(gpp_ano_ens2,4)]);
gpp_ano_ens3 = reshape(gpp_ano_ens3,[size(gpp_ano_ens3,1)*size(gpp_ano_ens3,2) size(gpp_ano_ens3,3) size(gpp_ano_ens3,4)]);

gpp_ano_ens1_total = squeeze(sum(gpp_ano_ens1,1,'omitnan'))*10^(-15);
gpp_ano_ens2_total = squeeze(sum(gpp_ano_ens2,1,'omitnan'))*10^(-15);
gpp_ano_ens3_total = squeeze(sum(gpp_ano_ens3,1,'omitnan'))*10^(-15);

for i = 1:10
gpp_ano_ens1_decade(:,i) = mean(gpp_ano_ens1_total(2+(i-1)*10:31+(i-1)*10,:),1);
gpp_ano_ens2_decade(:,i) = mean(gpp_ano_ens2_total(2+(i-1)*10:31+(i-1)*10,:),1);
gpp_ano_ens3_decade(:,i) = mean(gpp_ano_ens3_total(2+(i-1)*10:31+(i-1)*10,:),1);
end

mean(gpp_ano_ens3_decade,1)
%--------------------------------------------------------------------------
myncid = netcdf.create('fig5g.nc', 'NC_NOCLOBBER');
dimid1 = netcdf.defDim(myncid,'decade',10);
dimid2 = netcdf.defDim(myncid,'stat',2);
varid11 = netcdf.defVar(myncid,'gpp_ano_ens1_decade','double',[dimid1]);
varid12 = netcdf.defVar(myncid,'gpp_ano_ens1_decade_stat','double',[dimid1 dimid2]);
varid13 = netcdf.defVar(myncid,'gpp_ano_ens1_decade_stat2','double',[dimid1 dimid2]);
varid21 = netcdf.defVar(myncid,'gpp_ano_ens2_decade','double',[dimid1]);
varid22 = netcdf.defVar(myncid,'gpp_ano_ens2_decade_stat','double',[dimid1 dimid2]);
varid23 = netcdf.defVar(myncid,'gpp_ano_ens2_decade_stat2','double',[dimid1 dimid2]);
varid31 = netcdf.defVar(myncid,'gpp_ano_ens3_decade','double',[dimid1]);
varid32 = netcdf.defVar(myncid,'gpp_ano_ens3_decade_stat','double',[dimid1 dimid2]);
varid33 = netcdf.defVar(myncid,'gpp_ano_ens3_decade_stat2','double',[dimid1 dimid2]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid11, mean(gpp_ano_ens1_decade,1));
netcdf.putVar(myncid, varid12, [prctile(gpp_ano_ens1_decade,25,1)' prctile(gpp_ano_ens1_decade,75,1)']);
netcdf.putVar(myncid, varid13, [prctile(gpp_ano_ens1_decade,5,1)' prctile(gpp_ano_ens1_decade,95,1)']);
netcdf.putVar(myncid, varid21, mean(gpp_ano_ens2_decade,1));
netcdf.putVar(myncid, varid22, [prctile(gpp_ano_ens2_decade,25,1)' prctile(gpp_ano_ens2_decade,75,1)']);
netcdf.putVar(myncid, varid23, [prctile(gpp_ano_ens2_decade,5,1)' prctile(gpp_ano_ens2_decade,95,1)']);
netcdf.putVar(myncid, varid31, mean(gpp_ano_ens3_decade,1));
netcdf.putVar(myncid, varid32, [prctile(gpp_ano_ens3_decade,25,1)' prctile(gpp_ano_ens3_decade,75,1)']);
netcdf.putVar(myncid, varid33, [prctile(gpp_ano_ens3_decade,5,1)' prctile(gpp_ano_ens3_decade,95,1)']);
netcdf.close(myncid);

