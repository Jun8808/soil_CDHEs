clear all
clc

folder_path = 'H:\WORKS\34-Soil_CDHE\figure3\ERA5\';
nc_files  = dir(fullfile(folder_path, '*.nc'));
nc_files  = nc_files(1:38);
file_name = nc_files(1).name;
file_path = fullfile(nc_files(1).folder, file_name);
%ncdisp(file_path)
lon = ncread(file_path, 'longitude');
lat = ncread(file_path, 'latitude');
z500 = squeeze(ncread(file_path, 'z'));
u500 = squeeze(ncread(file_path, 'u'));
v500 = squeeze(ncread(file_path, 'v'));

ifactor = 2;
[z500_coarse, lon_new, lat_new] = aggregate_regrid(z500, ifactor, lon, lat);
[u500_coarse, lon_new, lat_new] = aggregate_regrid(u500, ifactor, lon, lat);
[v500_coarse, lon_new, lat_new] = aggregate_regrid(v500, ifactor, lon, lat);

for i = 2:length(nc_files)
    file_name = nc_files(i).name;
    file_path = fullfile(nc_files(i).folder, file_name);

    z500 = ncread(file_path, 'z');
    [z500_coarse_i, lon_new, lat_new] = aggregate_regrid(z500, ifactor, lon, lat);
    z500_coarse = cat(3,z500_coarse,z500_coarse_i);

    u500 = ncread(file_path, 'u');
    [u500_coarse_i, lon_new, lat_new] = aggregate_regrid(u500, ifactor, lon, lat);
    u500_coarse = cat(3,u500_coarse,u500_coarse_i);

    v500 = ncread(file_path, 'v');
    [v500_coarse_i, lon_new, lat_new] = aggregate_regrid(v500, ifactor, lon, lat);
    v500_coarse = cat(3,v500_coarse,v500_coarse_i);

    clear file_name file_path z500 z500_coarse_i u500 u500_coarse_i v500 v500_coarse_i
    disp(i)
end
clear lon lat

lon = [0.25:0.5:359.75];
lat = [-89.75:0.5:89.75];
[lat2d,lon2d]    = meshgrid(lat,lon);
[lat_new2d,lon_new2d]  = meshgrid(lat_new,lon_new);

for i = 1:size(z500_coarse,3)
z500(:,:,i) = interp2(lat_new2d,lon_new2d,z500_coarse(:,:,i),lat2d,lon2d);
u500(:,:,i) = interp2(lat_new2d,lon_new2d,u500_coarse(:,:,i),lat2d,lon2d);
v500(:,:,i) = interp2(lat_new2d,lon_new2d,v500_coarse(:,:,i),lat2d,lon2d);
disp(i)
end

clear z500_coarse u500_coarse v500_coarse
clear lat_new lon_new lat_new2d lon_new2d
%**************************************************************************
z500 = reshape(z500,[size(z500,1) size(z500,2) 12 size(z500,3)/12]) - ...
       repmat(mean(reshape(z500,[size(z500,1) size(z500,2) 12 size(z500,3)/12]),4),[1 1 1 38]);
z500 = squeeze(mean(z500(:,:,5:9,:),3));

u500 = reshape(u500,[size(u500,1) size(u500,2) 12 size(u500,3)/12]);
u500 = squeeze(mean(u500(:,:,5:9,:),3));

v500 = reshape(v500,[size(v500,1) size(v500,2) 12 size(v500,3)/12]);
v500 = squeeze(mean(v500(:,:,5:9,:),3));

years = [1980:2017]';
alpha = 0.05;

for j = 1:size(z500,2)
    for i = 1:size(z500,1)
        b = Theil_Sen_Regress(years,squeeze(z500(i,j,:)));
        [H,p_value] = Mann_Kendall(squeeze(z500(i,j,:)),alpha);  
        z500_trd(i,j) = b*10;
        z500_trd_sig(i,j) = H;

        b = Theil_Sen_Regress(years,squeeze(u500(i,j,:)));
        u500_trd(i,j) = b*10;

        b = Theil_Sen_Regress(years,squeeze(v500(i,j,:)));
        v500_trd(i,j) = b*10;
    end
    disp(j)
end

z500_trd = z500_trd - repmat(mean(z500_trd,1,'omitnan'),[size(z500_trd,1) 1]);

lon2d = repmat(lon',[1 length(lat)]);
lat2d = repmat(lat,[length(lon) 1]);

lon1d = reshape(lon2d,[size(lon2d,1)*size(lon2d,2) 1]);
lat1d = reshape(lat2d,[size(lat2d,1)*size(lat2d,2) 1]);

z500_trd_sig = reshape(z500_trd_sig,[size(z500_trd_sig,1)*size(z500_trd_sig,2) 1]);
lct = find(z500_trd_sig==1);
lonsig = lon1d(lct);
latsig = lat1d(lct);
clear lct
%**************************************************************************
myncid = netcdf.create('fig3a.nc', 'NC_NOCLOBBER');
dimid1 = netcdf.defDim(myncid,'lon',length(lon));
dimid2 = netcdf.defDim(myncid,'lat',length(lat));
dimid3 = netcdf.defDim(myncid,'sig',length(latsig));
varid1 = netcdf.defVar(myncid,'lon','double',dimid1);
varid2 = netcdf.defVar(myncid,'lat','double',dimid2);
varid3 = netcdf.defVar(myncid,'z500_trd','double',[dimid1 dimid2]);
varid4 = netcdf.defVar(myncid,'lonsig','double',[dimid3]);
varid5 = netcdf.defVar(myncid,'latsig','double',[dimid3]);
varid6 = netcdf.defVar(myncid,'u500_trd','double',[dimid1 dimid2]);
varid7 = netcdf.defVar(myncid,'v500_trd','double',[dimid1 dimid2]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid1, lon);
netcdf.putVar(myncid, varid2, lat);
netcdf.putVar(myncid, varid3, z500_trd);
netcdf.putVar(myncid, varid4, lonsig);
netcdf.putVar(myncid, varid5, latsig);
netcdf.putVar(myncid, varid6, u500_trd);
netcdf.putVar(myncid, varid7, v500_trd);
netcdf.reDef(myncid);
netcdf.putAtt(myncid, varid1,'units','degrees_north');
netcdf.putAtt(myncid, varid2,'units','degrees_east');
netcdf.close(myncid);

