clear all
clc
%--------------------------------------------------------------------------
nc_file = 'H:\WORKS\34-Soil_CDHE\figure2\China_Tsoil_regrid.nc';  % file name
% ncdisp(nc_file)
lonT     = ncread(nc_file, 'lon');
latT     = ncread(nc_file, 'lat');
tsoil   = ncread(nc_file, 'Tsoil_regrid');  % soil temperature at 10cm layer

clear nc_file
%--------------------------------------------------------------------------
nc_file = 'H:\WORKS\34-Soil_CDHE\figure2\China_Msoil_regrid.nc';  % file name
% ncdisp(nc_file)
lonM     = ncread(nc_file, 'lon');
latM     = ncread(nc_file, 'lat');
msoil    = ncread(nc_file, 'Msoil_regrid');  % soil temperature at 10cm layer

clear nc_file

latM  = latM(end:-1:1);
msoil = msoil(:,end:-1:1,:);
%--------------------------------------------------------------------------
lon = [72.75:0.5:136.75];
lat = [15.75:0.5:54.25];
[lat2d,lon2d]    = meshgrid(lat,lon);
[latT2d,lonT2d]  = meshgrid(latT,lonT);
[latM2d,lonM2d]  = meshgrid(latM,lonM);

for i = 1:size(tsoil,3)
tsoil_regrid(:,:,i) = interp2(latT2d,lonT2d,tsoil(:,:,i),lat2d,lon2d);
disp(i)
end

for i = 1:size(msoil,3)
msoil_regrid(:,:,i) = interp2(latM2d,lonM2d,msoil(:,:,i),lat2d,lon2d);
disp(i)
end
%contourf(sum(isnan(tsoil),3))

clear tsoil msoil lat2d lon2d latT lonT latM lonM latT2d lonT2d latM2d lonM2d

tsoil = tsoil_regrid;
msoil = msoil_regrid;
clear tsoil_regrid msoil_regrid

num_missing_t = sum(isnan(tsoil),3); % identify grid cells with missing T
num_missing_m = sum(isnan(msoil),3); % identify grid cells with missing M

for j = 1:length(lat)
    for i = 1:length(lon)
        if num_missing_t(i,j)~=0|num_missing_m(i,j)~=0
            tsoil(i,j,:) = NaN;
            msoil(i,j,:) = NaN;
        end
    end
end
%--------------------------------------------------------------------------
tsoil  = reshape(tsoil,[size(tsoil,1) size(tsoil,2) 365 size(tsoil,3)/365]);
msoil  = reshape(msoil,[size(msoil,1) size(msoil,2) 365 size(msoil,3)/365]);
%--------------------------------------------------------------------------
tsoil_c   = tsoil(:,:,:,2:31); % 1981-2010, climatology
msoil = reshape(msoil,[size(msoil,1) size(msoil,2) 365 38]);
msoil_c   = msoil(:,:,:,2:31); % 1981-2010, climatology

pts     = [0:10:100]; % percentiles

for p = 1:length(pts)
    for d = 1:153
        tsoil_sample = reshape(tsoil_c(:,:,d+120-7:d+120+7,:),[size(tsoil_c,1) size(tsoil_c,2) 15*30]);
        tsoil_pts(:,:,d,p)    = prctile(tsoil_sample,pts(p),3); % percentile
        clear tsoil_sample
    end

    for d = 1:153
        msoil_sample = reshape(msoil_c(:,:,d+120-7:d+120+7,:),[size(msoil_c,1) size(msoil_c,2) 15*30]);
        msoil_pts(:,:,d,p)    = prctile(msoil_sample,pts(p),3); % percentile
        clear msoil_sample
    end
    disp(p)
end


for j = 1:length(lat)
    for i = 1:length(lon)
        for yp = 1:length(pts)-1
            for xp = 1:length(pts)-1

            tsoil_extrm = squeeze(tsoil(i,j,121:273,:))>repmat(squeeze(tsoil_pts(i,j,:,xp)),[1 38])&squeeze(tsoil(i,j,121:273,:))<=repmat(squeeze(tsoil_pts(i,j,:,xp+1)),[1 38]);
            msoil_extrm = squeeze(msoil(i,j,121:273,:))>repmat(squeeze(msoil_pts(i,j,:,yp)),[1 38])&squeeze(msoil(i,j,121:273,:))<=repmat(squeeze(msoil_pts(i,j,:,yp+1)),[1 38]); 

            comp_extrm = tsoil_extrm==1&msoil_extrm==1;
            comp_extrm = comp_extrm(:,21:end); % 2000-2017
            comp_extrm = reshape(comp_extrm,[size(comp_extrm,1)*size(comp_extrm,2) 1]);

            lct = find(comp_extrm==1);
            comp_extrm_count(xp,yp,i,j) = length(lct);

            clear tsoil_extrm msoil_extrm comp_extrm lct
            end
        end
    end
disp(j)
end
%**************************************************************************
lon2d = repmat(lon',[1 length(lat)]);
lat2d = repmat(lat,[length(lon) 1]);

lon1d = reshape(lon2d,[size(lon2d,1)*size(lon2d,2) 1]);
lat1d = reshape(lat2d,[size(lat2d,1)*size(lat2d,2) 1]);

load H:\WORKS\34-Soil_CDHE\figure2\chngon
stmp=s(2);
load H:\WORKS\34-Soil_CDHE\figure2\chnpatch
s(1).long=stmp.long;
s(1).lat=stmp.lat; 

[in1 on1] = inpolygon(lon1d,lat1d,s(1).long,s(1).lat);
[in2 on2] = inpolygon(lon1d,lat1d,s(2).long,s(2).lat);
[in3 on3] = inpolygon(lon1d,lat1d,s(3).long,s(3).lat);

in = in1|in2|in3|on1|on2|on3;

comp_extrm_count = reshape(comp_extrm_count,[length(pts)-1 length(pts)-1 length(lon)*length(lat)]);

comp_extrm_count(:,:,find(in==0)) = NaN;

comp_extrm_prob = 100*comp_extrm_count./repmat(sum(sum(comp_extrm_count,1),2),[10 10 1]);
comp_extrm_prob = mean(comp_extrm_prob,3,'omitnan');
%**************************************************************************
myncid = netcdf.create('fig1c.nc', 'NC_NOCLOBBER');
dimid1 = netcdf.defDim(myncid,'xp',length(pts)-1);
dimid2 = netcdf.defDim(myncid,'yp',length(pts)-1);
varid1 = netcdf.defVar(myncid,'comp_extrm_prob','double',[dimid1 dimid2]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid1, comp_extrm_prob);
netcdf.close(myncid);


