clear all
clc

nc_file = 'H:\WORKS\34-Soil_CDHE\figure2\China_Tsoil_regrid.nc';  % file name
lonT     = ncread(nc_file, 'lon');
latT     = ncread(nc_file, 'lat');
tsoil   = ncread(nc_file, 'Tsoil_regrid');  % soil temperature at 10cm layer

clear nc_file
%--------------------------------------------------------------------------
nc_file = 'H:\WORKS\34-Soil_CDHE\figure2\China_Msoil_regrid.nc';  % file name
lonM     = ncread(nc_file, 'lon');
latM     = ncread(nc_file, 'lat');
msoil    = ncread(nc_file, 'Msoil_regrid');  % soil temperature at 10cm layer

clear nc_file

latM  = latM(end:-1:1);
msoil = msoil(:,end:-1:1,:);
%--------------------------------------------------------------------------
lon = [72.75:0.5:136.75];
lat = [15.75:0.5:54.25];
[lat2d,lon2d]    = meshgrid(lat,lon);
[latT2d,lonT2d]  = meshgrid(latT,lonT);
[latM2d,lonM2d]  = meshgrid(latM,lonM);

for i = 1:size(tsoil,3)
tsoil_regrid(:,:,i) = interp2(latT2d,lonT2d,tsoil(:,:,i),lat2d,lon2d);
disp(i)
end

for i = 1:size(msoil,3)
msoil_regrid(:,:,i) = interp2(latM2d,lonM2d,msoil(:,:,i),lat2d,lon2d);
disp(i)
end

clear tsoil msoil lat2d lon2d latT lonT latM lonM latT2d lonT2d latM2d lonM2d

tsoil = tsoil_regrid;
msoil = msoil_regrid;
clear tsoil_regrid msoil_regrid

num_missing_t = sum(isnan(tsoil),3); % identify grid cells with missing T
num_missing_m = sum(isnan(msoil),3); % identify grid cells with missing M

for j = 1:length(lat)
    for i = 1:length(lon)
        if num_missing_t(i,j)~=0|num_missing_m(i,j)~=0
            tsoil(i,j,:) = NaN;
            msoil(i,j,:) = NaN;
        end
    end
end

num_missing = sum(isnan(tsoil),3); % identify grid cells with missing T
num_missing = reshape(num_missing,[size(num_missing,1)*size(num_missing,2) 1]);
%**************************************************************************
lon2d = repmat(lon',[1 length(lat)]);
lat2d = repmat(lat,[length(lon) 1]);

lon1d = reshape(lon2d,[size(lon2d,1)*size(lon2d,2) 1]);
lat1d = reshape(lat2d,[size(lat2d,1)*size(lat2d,2) 1]);

load H:\WORKS\34-Soil_CDHE\figure2\chngon
stmp=s(2);
load H:\WORKS\34-Soil_CDHE\figure2\chnpatch
s(1).long=stmp.long;
s(1).lat=stmp.lat; 

[in1 on1] = inpolygon(lon1d,lat1d,s(1).long,s(1).lat);
[in2 on2] = inpolygon(lon1d,lat1d,s(2).long,s(2).lat);
[in3 on3] = inpolygon(lon1d,lat1d,s(3).long,s(3).lat);

in = in1|in2|in3|on1|on2|on3;
clear in1 in2 in3 on1 on2 on3
clear num_missing_m num_missing_t
%**************************************************************************
msoil_all_model = ncread('H:\WORKS\34-Soil_CDHE\figure4\historical_ano.nc','msoil_model');
tsoil_all_model = ncread('H:\WORKS\34-Soil_CDHE\figure4\historical_ano.nc','tsoil_model');

msoil_all_model = mean(msoil_all_model,4);
tsoil_all_model = mean(tsoil_all_model,4);

years   = [1980:2017]';

for j = 1:length(lat)
    for i = 1:length(lon)
        if isnan(msoil_all_model(i,j,1))==0 % identify the grids with valid values
        b = Theil_Sen_Regress(years,squeeze(msoil_all_model(i,j,:)));      % linear trend based on Theil-Se
        msoil_all_model_trd(i,j) = b*10;
        clear b
        b = Theil_Sen_Regress(years,squeeze(tsoil_all_model(i,j,:)));      % linear trend based on Theil-Sen
        tsoil_all_model_trd(i,j) = b*10;
        clear b
        else
        msoil_all_model_trd(i,j) = NaN;
        tsoil_all_model_trd(i,j) = NaN;
        end
    end
    disp(j)
end

msoil_all_model_trd = reshape(msoil_all_model_trd,[size(msoil_all_model_trd,1)*size(msoil_all_model_trd,2) 1]);
tsoil_all_model_trd = reshape(tsoil_all_model_trd,[size(tsoil_all_model_trd,1)*size(tsoil_all_model_trd,2) 1]);

clear msoil_all_model tsoil_all_model
%**************************************************************************
msoil_nat_model = ncread('H:\WORKS\34-Soil_CDHE\figure4\hist-nat_ano.nc','msoil_model');
tsoil_nat_model = ncread('H:\WORKS\34-Soil_CDHE\figure4\hist-nat_ano.nc','tsoil_model');

msoil_nat_model = mean(msoil_nat_model,4);
tsoil_nat_model = mean(tsoil_nat_model,4);

for j = 1:length(lat)
    for i = 1:length(lon)
        if isnan(msoil_nat_model(i,j,1))==0 % identify the grids with valid values
        b = Theil_Sen_Regress(years,squeeze(msoil_nat_model(i,j,:)));      % linear trend based on Theil-Se
        msoil_nat_model_trd(i,j) = b*10;
        clear b
        b = Theil_Sen_Regress(years,squeeze(tsoil_nat_model(i,j,:)));      % linear trend based on Theil-Sen
        tsoil_nat_model_trd(i,j) = b*10;
        clear b
        else
        msoil_nat_model_trd(i,j) = NaN;
        tsoil_nat_model_trd(i,j) = NaN;
        end
    end
    disp(j)
end

msoil_nat_model_trd = reshape(msoil_nat_model_trd,[size(msoil_nat_model_trd,1)*size(msoil_nat_model_trd,2) 1]);
tsoil_nat_model_trd = reshape(tsoil_nat_model_trd,[size(tsoil_nat_model_trd,1)*size(tsoil_nat_model_trd,2) 1]);

clear msoil_nat_model tsoil_nat_model
%**************************************************************************
lct  = find(num_missing~=0|in~=1|isnan(msoil_all_model_trd(:,1))~=0|isnan(tsoil_all_model_trd(:,1))~=0);

msoil = reshape(msoil,[size(msoil,1) size(msoil,2) 365 38]);
tsoil = reshape(tsoil,[size(tsoil,1) size(tsoil,2) 365 38]);

msoil_ano = msoil - repmat(mean(msoil(:,:,:,2:31),4),[1 1 1 38]);
tsoil_ano = tsoil - repmat(mean(tsoil(:,:,:,2:31),4),[1 1 1 38]);

msoil_ano = squeeze(mean(msoil_ano(:,:,121:273,:),3));
tsoil_ano = squeeze(mean(tsoil_ano(:,:,121:273,:),3));

for j = 1:length(lat)
    for i = 1:length(lon)
        if isnan(msoil_ano(i,j,1))==0 % identify the grids with valid values
        b = Theil_Sen_Regress(years,squeeze(msoil_ano(i,j,:)));  % linear trend based on Theil-Se
        msoil_obs_trd(i,j) = b*10;
        clear b
        b = Theil_Sen_Regress(years,squeeze(tsoil_ano(i,j,:)));  % linear trend based on Theil-Sen
        tsoil_obs_trd(i,j) = b*10;
        clear b
        else
        msoil_obs_trd(i,j) = NaN;
        tsoil_obs_trd(i,j) = NaN;
        end
    end
    disp(j)
end

msoil_obs_trd = reshape(msoil_obs_trd,[size(msoil_obs_trd,1)*size(msoil_obs_trd,2) 1]);
tsoil_obs_trd = reshape(tsoil_obs_trd,[size(tsoil_obs_trd,1)*size(tsoil_obs_trd,2) 1]);

clear msoil tsoil msoil_ano tsoil_ano

msoil_all_model_trd(lct) = NaN;
tsoil_all_model_trd(lct) = NaN;
msoil_nat_model_trd(lct) = NaN;
tsoil_nat_model_trd(lct) = NaN;

msoil_obs_trd(lct) = NaN;
tsoil_obs_trd(lct) = NaN;

msoil_ant_model_trd = msoil_all_model_trd - msoil_nat_model_trd;
tsoil_ant_model_trd = tsoil_all_model_trd - tsoil_nat_model_trd;

msoil_obs_trd = reshape(msoil_obs_trd,[length(lon) length(lat)]);
tsoil_obs_trd = reshape(tsoil_obs_trd,[length(lon) length(lat)]);

msoil_ant_model_trd = reshape(msoil_ant_model_trd,[length(lon) length(lat)]);
tsoil_ant_model_trd = reshape(tsoil_ant_model_trd,[length(lon) length(lat)]);

msoil_obs_trd(find(isnan(msoil_obs_trd)==1)) = -999;
tsoil_obs_trd(find(isnan(tsoil_obs_trd)==1)) = -999;
msoil_ant_model_trd(find(isnan(msoil_ant_model_trd)==1)) = -999;
tsoil_ant_model_trd(find(isnan(tsoil_ant_model_trd)==1)) = -999;
%**************************************************************************
myncid = netcdf.create('fig4cd.nc', 'NC_NOCLOBBER');
dimid1 = netcdf.defDim(myncid,'lon',length(lon));
dimid2 = netcdf.defDim(myncid,'lat',length(lat));
varid1 = netcdf.defVar(myncid,'lon','double',dimid1);
varid2 = netcdf.defVar(myncid,'lat','double',dimid2);
varid3 = netcdf.defVar(myncid,'msoil_obs_trd','double',[dimid1 dimid2]);
varid4 = netcdf.defVar(myncid,'tsoil_obs_trd','double',[dimid1 dimid2]);
varid5 = netcdf.defVar(myncid,'msoil_ant_model_trd','double',[dimid1 dimid2]);
varid6 = netcdf.defVar(myncid,'tsoil_ant_model_trd','double',[dimid1 dimid2]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid1, lon);
netcdf.putVar(myncid, varid2, lat);
netcdf.putVar(myncid, varid3, msoil_obs_trd);
netcdf.putVar(myncid, varid4, tsoil_obs_trd);
netcdf.putVar(myncid, varid5, msoil_ant_model_trd);
netcdf.putVar(myncid, varid6, tsoil_ant_model_trd);
netcdf.reDef(myncid);
netcdf.putAtt(myncid, varid1,'units','degrees_north');
netcdf.putAtt(myncid, varid2,'units','degrees_east');
netcdf.close(myncid);
