clear all
clc

folder_path = 'H:\WORKS\34-Soil_CDHE\figure3\ERA5\';
nc_files  = dir(fullfile(folder_path, '*.nc'));
nc_files  = nc_files(1:38);
file_name = nc_files(1).name;
file_path = fullfile(nc_files(1).folder, file_name);
%ncdisp(file_path)
lon = ncread(file_path, 'longitude');
lat = ncread(file_path, 'latitude');
z500 = squeeze(ncread(file_path, 'z'));

ifactor = 2;
[z500_coarse, lon_new, lat_new] = aggregate_regrid(z500, ifactor, lon, lat);

for i = 2:length(nc_files)
    file_name = nc_files(i).name;
    file_path = fullfile(nc_files(i).folder, file_name);

    z500 = ncread(file_path, 'z');
    [z500_coarse_i, lon_new, lat_new] = aggregate_regrid(z500, ifactor, lon, lat);
    z500_coarse = cat(3,z500_coarse,z500_coarse_i);

    clear file_name file_path z500 z500_coarse_i
    disp(i)
end
clear lon lat

lon = [0.25:0.5:359.75];
lat = [-89.75:0.5:89.75];
[lat2d,lon2d]    = meshgrid(lat,lon);
[lat_new2d,lon_new2d]  = meshgrid(lat_new,lon_new);

for i = 1:size(z500_coarse,3)
z500(:,:,i) = interp2(lat_new2d,lon_new2d,z500_coarse(:,:,i),lat2d,lon2d);
disp(i)
end

clear z500_coarse lat_new lon_new lat_new2d lon_new2d

z500 = reshape(z500,[size(z500,1) size(z500,2) 12 size(z500,3)/12]) - ...
       repmat(mean(reshape(z500,[size(z500,1) size(z500,2) 12 size(z500,3)/12]),4),[1 1 1 38]);
z500 = squeeze(mean(z500(:,:,5:9,:),3));

z500 = z500 - repmat(mean(z500,1,'omitnan'),[720 1 1]);
z500 = z500(146:274,212:289,:);
%**************************************************************************
lati = ncread('H:\WORKS\34-Soil_CDHE\figure3\E_regrid.nc','lat');
loni = ncread('H:\WORKS\34-Soil_CDHE\figure3\E_regrid.nc','lon');

lon = [72.75:0.5:136.75];
lat = [15.75:0.5:54.25];
[lat2d,lon2d]      = meshgrid(lat,lon);
[lati_2d,loni_2d]  = meshgrid(lati,loni);

E    = ncread('H:\WORKS\34-Soil_CDHE\figure3\E_regrid.nc','E');
for i = 1:size(E,3)
E_regrid(:,:,i)  = interp2(lati_2d,loni_2d,E(:,:,i),lat2d,lon2d);
disp(i)
end
clear E
E  = E_regrid;
clear E_regrid

Ep   = ncread('H:\WORKS\34-Soil_CDHE\figure3\Ep_regrid.nc','Ep');
for i = 1:size(Ep,3)
Ep_regrid(:,:,i) = interp2(lati_2d,loni_2d,Ep(:,:,i),lat2d,lon2d);
disp(i)
end
clear Ep
Ep = Ep_regrid;
clear Ep_regrid

H    = ncread('H:\WORKS\34-Soil_CDHE\figure3\H_regrid.nc','H');
for i = 1:size(H,3)
H_regrid(:,:,i)  = interp2(lati_2d,loni_2d,H(:,:,i),lat2d,lon2d);
disp(i)
end
clear H
H  = H_regrid;
clear H_regrid
%**************************************************************************
E  = reshape(E,[size(E,1) size(E,2) 365 size(E,3)/365]);     % unit: mm/day
Ep = reshape(Ep,[size(Ep,1) size(Ep,2) 365 size(Ep,3)/365]); % unit: mm/day
H  = reshape(H,[size(H,1) size(H,2) 365 size(H,3)/365]);     % unit: W/m2

Ld = 2.5*10^6; % unit: J/kg
Hp = H - Ld*(Ep-E)/(24*3600); % (J/kg)*(mm/s) = W/m2

clear E Ep
%**************************************************************************
nc_file = 'H:\WORKS\34-Soil_CDHE\figure2\China_Tsoil_regrid.nc';  % file name
% ncdisp(nc_file)
lonT     = ncread(nc_file, 'lon');
latT     = ncread(nc_file, 'lat');
tsoil   = ncread(nc_file, 'Tsoil_regrid');  % soil temperature at 10cm layer
[latT2d,lonT2d]  = meshgrid(latT,lonT);
clear nc_file

for i = 1:size(tsoil,3)
tsoil_regrid(:,:,i) = interp2(latT2d,lonT2d,tsoil(:,:,i),lat2d,lon2d);
disp(i)
end  
clear tsoil
tsoil = tsoil_regrid;
clear tsoil_regrid

tsoil  = reshape(tsoil,[size(tsoil,1) size(tsoil,2) 365 size(tsoil,3)/365]);
%**************************************************************************
H_ano     = H - repmat(mean(H(:,:,:,2:31),4),[1 1 1 38]);
Hp_ano    = Hp - repmat(mean(Hp(:,:,:,2:31),4),[1 1 1 38]);
tsoil_ano = tsoil - repmat(mean(tsoil(:,:,:,2:31),4),[1 1 1 38]);

H_ano     = H_ano(:,:,121:273,:);
Hp_ano    = Hp_ano(:,:,121:273,:);
tsoil_ano = tsoil_ano(:,:,121:273,:);

H_ano     = (H - repmat(mean(H(:,:,:,2:31),4),[1 1 1 38]))./repmat(std(H(:,:,:,2:31),0,4),[1 1 1 38]);
Hp_ano    = (Hp - repmat(mean(Hp(:,:,:,2:31),4),[1 1 1 38]))./repmat(std(Hp(:,:,:,2:31),0,4),[1 1 1 38]);
tsoil_ano = (tsoil - repmat(mean(tsoil(:,:,:,2:31),4),[1 1 1 38]))./repmat(std(tsoil(:,:,:,2:31),0,4),[1 1 1 38]);

H_ano     = reshape(H_ano(:,:,121:273,:),[size(H_ano,1) size(H_ano,2) 153*38]);
Hp_ano    = reshape(Hp_ano(:,:,121:273,:),[size(Hp_ano,1) size(Hp_ano,2) 153*38]);
tsoil_ano = reshape(tsoil_ano(:,:,121:273,:),[size(tsoil_ano,1) size(tsoil_ano,2) 153*38]);

small_pi  = (H_ano-Hp_ano).*tsoil_ano;
big_pi    = squeeze(mean(reshape(small_pi,[size(small_pi,1) size(small_pi,2) 153 38]),3));

clear H H_ano Hp Hp_ano tsoil tsoil_ano
clear lati lati_2d loni loni_2d latT latT2d lonT lonT2d

comp_extrm_frq = ncread('H:\WORKS\34-Soil_CDHE\figure2\fig2.nc','comp_extrm_frq');

z500(find(isnan(comp_extrm_frq)==1))  = NaN;
big_pi(find(isnan(comp_extrm_frq)==1))= NaN;
%**************************************************************************
z500_sel   = z500(36:105,50:69,:); % 90-125E;40-50N
big_pi_sel = big_pi(36:105,50:69,:);
comp_extrm_frq_sel = comp_extrm_frq(36:105,50:69,:); 

z500_sel   = reshape(z500_sel,[size(z500_sel,1)*size(z500_sel,2) size(z500_sel,3)]);
big_pi_sel = reshape(big_pi_sel,[size(big_pi_sel,1)*size(big_pi_sel,2) size(big_pi_sel,3)]);
comp_extrm_frq_sel = reshape(comp_extrm_frq_sel,[size(comp_extrm_frq_sel,1)*size(comp_extrm_frq_sel,2) size(comp_extrm_frq_sel,3)]);

lct = find(isnan(z500_sel(:,1))==0);

lat1d   = reshape(lat2d,[size(lat2d,1)*size(lat2d,2) 1]);
weight  = cos(pi*lat1d(lct)/180.0);
weights = weight/mean(weight);

z500_reg   = mean(z500_sel(lct,:).*repmat(weights,[1 38]),1);
big_pi_reg = mean(big_pi_sel(lct,:).*repmat(weights,[1 38]),1);
comp_extrm_frq_reg  = mean(comp_extrm_frq_sel(lct,:).*repmat(weights,[1 38]),1);

years = [1980:2017]';
% plotyy(years,z500_reg,years,comp_extrm_frq_reg)
% plotyy(years,big_pi_reg,years,comp_extrm_frq_reg)
% [R, P] = corrcoef(z500_reg,comp_extrm_frq_reg)
% [R, P] = corrcoef(big_pi_reg,comp_extrm_frq_reg)
%**************************************************************************
myncid = netcdf.create('fig3c.nc', 'NC_NOCLOBBER');
dimid1 = netcdf.defDim(myncid,'years',38);
varid1 = netcdf.defVar(myncid,'z500_reg','double',dimid1);
varid2 = netcdf.defVar(myncid,'big_pi_reg','double',dimid1);
varid3 = netcdf.defVar(myncid,'comp_extrm_frq_reg','double',dimid1);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid1, z500_reg);
netcdf.putVar(myncid, varid2, big_pi_reg);
netcdf.putVar(myncid, varid3, comp_extrm_frq_reg);
netcdf.close(myncid);

