All these MATLAB codes can be used to reproduce the main results presented in the manuscript.
You can download and install MATLAB from https://ww2.mathworks.cn/en/products/matlab.html.
The instructions for installing and running MATLAB can be found at https://ww2.mathworks.cn/help/install/ug/install-products-with-internet-connection.html.
The typical install time is about 20 minutes.
The MATLAB can be installed for many platforms, including Windows, Linux, macOS.
The MATLAB version that we are currently using is R2023b.
If you install the MATBAL successfully, you can double-click the MATLAB codes and run them.
The expected output of MATLAB can be mat. or netcdf files.

All data supporting the findings are publicly available. The gridded daily soil temperature data in China are available at https://www.scidb.cn/en/detail?dataSetId=765528002485288960&version=V3. The Global Land Evaporation Amsterdam Model soil moisture and surface sensible and latent heat flux data are available at https://www.gleam.eu/. The solar-induced chlorophyll fluorescence and gross primary production datasets are available at https://daac.ornl.gov/VEGETATION/guides/FluxSat_GPP_FPAR.html and http://casearthpoles.tpdc.ac.cn/zh-hans/data/d7cccf31-9bb5-4356-88a7-38c5458f052b/. The ERA5 reanalysis dataset is available at https://www.ecmwf.int/en/forecasts/dataset/ecmwf-reanalysis-v5. The climate simulation data are from https://pcmdi.llnl.gov/CMIP6/. The land-use/land-cover dataset is available at https://zenodo.org/records/4417810.



