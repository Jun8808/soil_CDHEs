clear all
clc

lon = ncread('H:\WORKS\34-Soil_CDHE\figure5\historical_ssp585.nc','lon');
lat = ncread('H:\WORKS\34-Soil_CDHE\figure5\historical_ssp585.nc','lat');
comp_extrm_frq_ens = ncread('H:\WORKS\34-Soil_CDHE\figure5\historical_ssp585.nc','comp_extrm_frq');
comp_extrm_frq_ens = reshape(comp_extrm_frq_ens,[size(comp_extrm_frq_ens,1)*size(comp_extrm_frq_ens,2) size(comp_extrm_frq_ens,3) size(comp_extrm_frq_ens,4)]);

lon2d = repmat(lon',[1 length(lat)]);
lat2d = repmat(lat,[length(lon) 1]);

lon1d = reshape(lon2d,[size(lon2d,1)*size(lon2d,2) 1]);
lat1d = reshape(lat2d,[size(lat2d,1)*size(lat2d,2) 1]);

comp_extrm_frq_obs = ncread('H:\WORKS\34-Soil_CDHE\figure2\fig2.nc','comp_extrm_frq');
comp_extrm_frq_obs = reshape(comp_extrm_frq_obs,[size(comp_extrm_frq_obs,1)*size(comp_extrm_frq_obs,2) size(comp_extrm_frq_obs,3)]);

comp_extrm_frq_ens_mean = mean(mean(comp_extrm_frq_ens,3),2);
comp_extrm_frq_obs_mean = mean(comp_extrm_frq_obs,2);

lct = find(isnan(comp_extrm_frq_obs_mean)==0&comp_extrm_frq_ens_mean~=0);

weight  = cos(pi*lat1d(lct)/180.0);
weights = weight/mean(weight);

comp_extrm_frq_ens_reg = squeeze(mean(comp_extrm_frq_ens(lct,:,:).*repmat(weights,[1 121 30]),1));
comp_extrm_frq_obs_reg = mean(comp_extrm_frq_obs(lct,:).*repmat(weights,[1 38]),1)';

comp_extrm_frq_ens_reg = comp_extrm_frq_ens_reg-repmat(mean(comp_extrm_frq_ens_reg(2:31,:),1),[121 1]);
comp_extrm_frq_obs_reg = comp_extrm_frq_obs_reg-mean(comp_extrm_frq_obs_reg(2:31));

years   = [1980:2017]';
alpha   = 0.001;
% b = Theil_Sen_Regress(years,comp_extrm_frq_obs_reg)
% datain = [years comp_extrm_frq_obs_reg];
% [taub tau h sig Z S sigma sen n senplot CIlower CIupper D Dall C3 nsigma] = ktaub(datain, 0.05, 0)

% b = Theil_Sen_Regress(years,mean(comp_extrm_frq_ens_reg(1:38,:),2))
mean(mean(comp_extrm_frq_ens_reg(92:121,:),2),1)-mean(mean(comp_extrm_frq_ens_reg(2:31,:),2),1)
prctile(mean(comp_extrm_frq_ens_reg(92:121,:),1)-mean(comp_extrm_frq_ens_reg(2:31,:),1),5)
prctile(mean(comp_extrm_frq_ens_reg(92:121,:),1)-mean(comp_extrm_frq_ens_reg(2:31,:),1),95)
%**************************************************************************
myncid = netcdf.create('fig5c.nc', 'NC_NOCLOBBER');
dimid0 = netcdf.defDim(myncid,'years0',38);
dimid1 = netcdf.defDim(myncid,'years',121);
dimid2 = netcdf.defDim(myncid,'stat',2);
varid1 = netcdf.defVar(myncid,'comp_extrm_frq_obs_reg','double',[dimid0]);
varid2 = netcdf.defVar(myncid,'comp_extrm_frq_ens_reg_mean','double',[dimid1]);
varid3 = netcdf.defVar(myncid,'comp_extrm_frq_ens_reg_stat','double',[dimid1 dimid2]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid1, comp_extrm_frq_obs_reg);
netcdf.putVar(myncid, varid2, mean(comp_extrm_frq_ens_reg,2));
netcdf.putVar(myncid, varid3, [prctile(comp_extrm_frq_ens_reg,5,2) prctile(comp_extrm_frq_ens_reg,95,2)]);
netcdf.close(myncid);    








