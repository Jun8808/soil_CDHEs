clear all
clc

lat      = ncread('H:\WORKS\34-Soil_CDHE\figure2\fig2.nc','lat');
lon      = ncread('H:\WORKS\34-Soil_CDHE\figure2\fig2.nc','lon');
comp_extrm_frq_trd = ncread('H:\WORKS\34-Soil_CDHE\figure2\fig2.nc','comp_extrm_frq_trd');

latz = ncread('H:\WORKS\34-Soil_CDHE\figure3\fig3a.nc','lat');
lonz = ncread('H:\WORKS\34-Soil_CDHE\figure3\fig3a.nc','lon');
z500_trd = ncread('H:\WORKS\34-Soil_CDHE\figure3\fig3a.nc','z500_trd');
z500_trd = z500_trd(146:274,212:289,:);

small_pi_trd   = ncread('H:\WORKS\34-Soil_CDHE\figure3\fig3b.nc','small_pi_trd');

lct = find(comp_extrm_frq_trd==-999);
comp_extrm_frq_trd(lct) = NaN;
small_pi_trd(lct)   = NaN;
z500_trd(lct) = NaN;
%**************************************************************************
bin_z  = [-20:2:20];
bin_pi = [-0.25:0.025:0.25];

heat_map = zeros(length(bin_z)+1,length(bin_pi)+1);

for j = 1:length(bin_pi)+1
    for i = 1:length(bin_z)+1
        if (i==1)&(j==1)
            lct = find(z500_trd<bin_z(i)&small_pi_trd<bin_pi(j));

       elseif (i==1)&(j>=2)&(j<=length(bin_pi))
            lct = find(z500_trd<bin_z(i)&small_pi_trd>=bin_pi(j-1)&small_pi_trd<bin_pi(j));    

        elseif (i==1)&(j==length(bin_pi)+1)
            lct = find(z500_trd<bin_z(i)&small_pi_trd>=bin_pi(j-1));

        elseif (i>=2)&(i<=length(bin_z))&(j==length(bin_pi)+1)
            lct = find(z500_trd>=bin_z(i-1)&z500_trd<bin_z(i)&small_pi_trd>=bin_pi(j-1));    

        elseif (i==length(bin_z)+1)&(j==length(bin_pi)+1)
            lct = find(z500_trd>=bin_z(i-1)&small_pi_trd>=bin_pi(j-1));

        elseif (i==length(bin_z)+1)&(j>=2)&(j<=length(bin_pi))
            lct = find(z500_trd>=bin_z(i-1)&small_pi_trd>=bin_pi(j-1)&small_pi_trd<bin_pi(j));

        elseif (i==length(bin_z)+1)&(j==1)
            lct = find(z500_trd>=bin_z(i-1)&small_pi_trd<bin_pi(j));

        elseif (i>=2)&(i<=length(bin_z))&(j==1)
            lct = find(z500_trd>=bin_z(i-1)&z500_trd<bin_z(i)&small_pi_trd<bin_pi(j));

        else
            lct = find(z500_trd>=bin_z(i-1)&z500_trd<bin_z(i)&small_pi_trd>=bin_pi(j-1)&small_pi_trd<bin_pi(j));
        end


        if length(lct)~=0
            heat_map(i,j) = mean(comp_extrm_frq_trd(lct),'omitnan');
        else
            heat_map(i,j) = NaN;
        end
    end
end

heat_map(find(isnan(heat_map)==1)) = -999;
%**************************************************************************
myncid = netcdf.create('fig3d.nc', 'NC_NOCLOBBER');
dimid1 = netcdf.defDim(myncid,'z',length(bin_z)+1);
dimid2 = netcdf.defDim(myncid,'pi',length(bin_pi)+1);
varid1 = netcdf.defVar(myncid,'bin_z','double',dimid1);
varid2 = netcdf.defVar(myncid,'bin_pi','double',dimid2);
varid3 = netcdf.defVar(myncid,'heat_map','double',[dimid1 dimid2]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid1, [-22 bin_z]);
netcdf.putVar(myncid, varid2, [-0.275 bin_pi]);
netcdf.putVar(myncid, varid3, heat_map);
netcdf.close(myncid);

