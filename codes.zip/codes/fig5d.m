clear all
clc

lon = ncread('H:\WORKS\34-Soil_CDHE\figure5\historical_ssp126.nc','lon');
lat = ncread('H:\WORKS\34-Soil_CDHE\figure5\historical_ssp126.nc','lat');

lon2d = repmat(lon,[1 length(lat)]);
lat2d = repmat(lat',[length(lon) 1]);

lon1d = reshape(lon2d,[size(lon2d,1)*size(lon2d,2) 1]);
lat1d = reshape(lat2d,[size(lat2d,1)*size(lat2d,2) 1]);

comp_extrm_frq_obs = ncread('H:\WORKS\34-Soil_CDHE\figure2\fig2.nc','comp_extrm_frq');
comp_extrm_frq_obs = reshape(comp_extrm_frq_obs,[size(comp_extrm_frq_obs,1)*size(comp_extrm_frq_obs,2) size(comp_extrm_frq_obs,3)]);
comp_extrm_frq_obs_mean = mean(comp_extrm_frq_obs,2);

comp_extrm_frq_ens = ncread('H:\WORKS\34-Soil_CDHE\figure5\historical_ssp126.nc','comp_extrm_frq');
comp_extrm_frq_ens_mean = mean(mean(comp_extrm_frq_ens,4),3);
comp_extrm_frq_ens_mean = reshape(comp_extrm_frq_ens_mean,[size(comp_extrm_frq_ens_mean,1)*size(comp_extrm_frq_ens_mean,2) 1]);
comp_extrm_frq_ens = reshape(comp_extrm_frq_ens,[size(comp_extrm_frq_ens,1)*size(comp_extrm_frq_ens,2) size(comp_extrm_frq_ens,3) size(comp_extrm_frq_ens,4)]);
lct = find(isnan(comp_extrm_frq_obs_mean)==1|comp_extrm_frq_ens_mean==0);

comp_extrm_frq_ens(lct,:,:) = NaN;
comp_extrm_frq_ens = reshape(comp_extrm_frq_ens,[129 78 121 50]);

cnlcf = ncread('H:\WORKS\34-Soil_CDHE\figure5\cnlcf.nc','cnlcf');
cnlcf_sum = sum(cnlcf,3);
cnlcf_sum = reshape(cnlcf_sum,[size(cnlcf_sum,1)*size(cnlcf_sum,2) 1]);
cnlcf = reshape(cnlcf,[size(cnlcf,1)*size(cnlcf,2) size(cnlcf,3)]);
lct   = find(cnlcf_sum==0|isnan(cnlcf_sum)==1);
cnlcf(lct,:) = NaN;
cnlcf = reshape(cnlcf,[129 78 9]);

for j = 1:length(lat)
    for i = 1:length(lon)
        areas(i,j) = 6.371*6.371*(10^6)*(pi*0.5/180.0)*(sin(pi*(lat(j)+0.25)/180.0)-sin(pi*(lat(j)-0.25)/180.0)); 
    end
end
lct   = find(isnan(comp_extrm_frq_obs_mean)==1|comp_extrm_frq_ens_mean==0|cnlcf_sum==0|isnan(cnlcf_sum)==1);
areas(lct) = NaN;

for m = 1:9
comp_extrm_exp = comp_extrm_frq_ens.*repmat(cnlcf(:,:,m),[1 1 size(comp_extrm_frq_ens,3) size(comp_extrm_frq_ens,4)]).*repmat(areas,[1 1 size(comp_extrm_frq_ens,3) size(comp_extrm_frq_ens,4)]);
comp_extrm_exp = reshape(comp_extrm_exp,[size(comp_extrm_exp,1)*size(comp_extrm_exp,2) size(comp_extrm_exp,3) size(comp_extrm_exp,4)]);
comp_extrm_exp_reg(:,:,m) = squeeze(sum(comp_extrm_exp,1,'omitnan'));

clear comp_extrm_exp 
disp(m)
end

cnlcf_reg = squeeze(sum(sum(cnlcf.*repmat(areas,[1 1 9]),2,'omitnan'),1));

for m = 1:9
comp_extrm_exp_reg_frq(:,:,m) = comp_extrm_exp_reg(:,:,m)./repmat(cnlcf_reg(m),[121 50]);
end
% plot(squeeze(mean(comp_extrm_exp_reg_frq(:,:,:),2)))

comp_extrm_exp_reg_frq_diff = squeeze(mean(comp_extrm_exp_reg_frq(92:end,:,:),1)-mean(comp_extrm_exp_reg_frq(2:31,:,:),1));
comp_extrm_exp_reg_frq_diff_perc = squeeze(mean(comp_extrm_exp_reg_frq(92:end,:,:),1)-mean(comp_extrm_exp_reg_frq(2:31,:,:),1))...
                                   ./squeeze(mean(comp_extrm_exp_reg_frq(2:31,:,:),1));

comp_extrm_exp_reg_frq_diff = comp_extrm_exp_reg_frq_diff(:,[1 2 3 4 7 8]);
comp_extrm_exp_reg_frq_diff_perc = comp_extrm_exp_reg_frq_diff_perc(:,[1 2 3 4 7 8]);
%**************************************************************************
myncid = netcdf.create('fig5d.nc', 'NC_NOCLOBBER');
dimid1 = netcdf.defDim(myncid,'type',6);
dimid2 = netcdf.defDim(myncid,'stat',2);
varid1 = netcdf.defVar(myncid,'comp_extrm_exp_reg_frq_diff','double',dimid1);
varid2 = netcdf.defVar(myncid,'comp_extrm_exp_reg_frq_diff_perc','double',dimid1);
varid3 = netcdf.defVar(myncid,'comp_extrm_exp_reg_frq_diff_stat','double',[dimid1 dimid2]);
varid4 = netcdf.defVar(myncid,'comp_extrm_exp_reg_frq_diff_perc_stat','double',[dimid1 dimid2]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid1, median(comp_extrm_exp_reg_frq_diff,1)');
netcdf.putVar(myncid, varid2, median(comp_extrm_exp_reg_frq_diff_perc,1)');
netcdf.putVar(myncid, varid3, [prctile(comp_extrm_exp_reg_frq_diff,5,1)' prctile(comp_extrm_exp_reg_frq_diff,95,1)']);
netcdf.putVar(myncid, varid4, [prctile(comp_extrm_exp_reg_frq_diff_perc,5,1)' prctile(comp_extrm_exp_reg_frq_diff_perc,95,1)']);
netcdf.close(myncid);  
