clear all
clc

nc_file = 'H:\WORKS\34-Soil_CDHE\figure2\China_Tsoil_regrid.nc';  % file name
lonT     = ncread(nc_file, 'lon');
latT     = ncread(nc_file, 'lat');
tsoil   = ncread(nc_file, 'Tsoil_regrid');  % soil temperature at 10cm layer

clear nc_file
%--------------------------------------------------------------------------
nc_file = 'H:\WORKS\34-Soil_CDHE\figure2\China_Msoil_regrid.nc';  % file name
lonM     = ncread(nc_file, 'lon');
latM     = ncread(nc_file, 'lat');
msoil    = ncread(nc_file, 'Msoil_regrid');  % soil temperature at 10cm layer

clear nc_file

latM  = latM(end:-1:1);
msoil = msoil(:,end:-1:1,:)*100;
%--------------------------------------------------------------------------
lon = [72.75:0.5:136.75];
lat = [15.75:0.5:54.25];
[lat2d,lon2d]    = meshgrid(lat,lon);
[latT2d,lonT2d]  = meshgrid(latT,lonT);
[latM2d,lonM2d]  = meshgrid(latM,lonM);

for i = 1:size(tsoil,3)
tsoil_regrid(:,:,i) = interp2(latT2d,lonT2d,tsoil(:,:,i),lat2d,lon2d);
disp(i)
end

for i = 1:size(msoil,3)
msoil_regrid(:,:,i) = interp2(latM2d,lonM2d,msoil(:,:,i),lat2d,lon2d);
disp(i)
end

clear tsoil msoil lat2d lon2d latT lonT latM lonM latT2d lonT2d latM2d lonM2d

tsoil = tsoil_regrid;
msoil = msoil_regrid;
clear tsoil_regrid msoil_regrid

num_missing_t = sum(isnan(tsoil),3); % identify grid cells with missing T
num_missing_m = sum(isnan(msoil),3); % identify grid cells with missing M

for j = 1:length(lat)
    for i = 1:length(lon)
        if num_missing_t(i,j)~=0|num_missing_m(i,j)~=0
            tsoil(i,j,:) = NaN;
            msoil(i,j,:) = NaN;
        end
    end
end

num_missing = sum(isnan(tsoil),3); % identify grid cells with missing T
num_missing = reshape(num_missing,[size(num_missing,1)*size(num_missing,2) 1]);
%**************************************************************************
lon2d = repmat(lon',[1 length(lat)]);
lat2d = repmat(lat,[length(lon) 1]);

lon1d = reshape(lon2d,[size(lon2d,1)*size(lon2d,2) 1]);
lat1d = reshape(lat2d,[size(lat2d,1)*size(lat2d,2) 1]);

load H:\WORKS\34-Soil_CDHE\figure2\chngon
stmp=s(2);
load H:\WORKS\34-Soil_CDHE\figure2\chnpatch
s(1).long=stmp.long;
s(1).lat=stmp.lat; 

[in1 on1] = inpolygon(lon1d,lat1d,s(1).long,s(1).lat);
[in2 on2] = inpolygon(lon1d,lat1d,s(2).long,s(2).lat);
[in3 on3] = inpolygon(lon1d,lat1d,s(3).long,s(3).lat);

in = in1|in2|in3|on1|on2|on3;
clear in1 in2 in3 on1 on2 on3
clear num_missing_m num_missing_t
%**************************************************************************
msoil_all_model = ncread('H:\WORKS\34-Soil_CDHE\figs5\historical_ano_mon.nc','msoil_model');
tsoil_all_model = ncread('H:\WORKS\34-Soil_CDHE\figs5\historical_ano_mon.nc','tsoil_model');

msoil_nat_model = ncread('H:\WORKS\34-Soil_CDHE\figs5\hist-nat_ano_mon.nc','msoil_model');
tsoil_nat_model = ncread('H:\WORKS\34-Soil_CDHE\figs5\hist-nat_ano_mon.nc','tsoil_model');

msoil_ant_model = mean(msoil_all_model - msoil_nat_model,5);
tsoil_ant_model = mean(tsoil_all_model - tsoil_nat_model,5);

msoil_ant_model = msoil_ant_model - repmat(msoil_ant_model(:,:,:,1),[1 1 1 38]);
tsoil_ant_model = tsoil_ant_model - repmat(tsoil_ant_model(:,:,:,1),[1 1 1 38]);

clear msoil_all_model tsoil_all_model msoil_nat_model tsoil_nat_model

mdata_model = reshape(msoil_ant_model(:,:,1,1),[length(lon)*length(lat) 1]);
tdata_model = reshape(tsoil_ant_model(:,:,1,1),[length(lon)*length(lat) 1]);
%**************************************************************************
msoil = reshape(msoil,[size(msoil,1) size(msoil,2) 365 38]);
tsoil = reshape(tsoil,[size(tsoil,1) size(tsoil,2) 365 38]);

mons = [1;32;60;91;121;152;182;213;244;274;305;335;366];

msoil_without_ant = zeros(size(msoil));
tsoil_without_ant = zeros(size(tsoil));

for m = 1:length(mons)-1
msoil_without_ant(:,:,mons(m):mons(m+1)-1,:) = msoil(:,:,mons(m):mons(m+1)-1,:) - repmat(msoil_ant_model(:,:,m,:),[1 1 (mons(m+1)-mons(m)) 1]);
tsoil_without_ant(:,:,mons(m):mons(m+1)-1,:) = tsoil(:,:,mons(m):mons(m+1)-1,:) - repmat(tsoil_ant_model(:,:,m,:),[1 1 (mons(m+1)-mons(m)) 1]);
disp(m)
end

clear msoil_ant_model tsoil_ant_model
%**************************************************************************
tsoil = reshape(tsoil,[size(tsoil,1) size(tsoil,2) 365 38]);

tsoil_c   = tsoil(:,:,:,2:31); % 1981-2010, climatology
tsoil_p90 = zeros(size(tsoil_c,1),size(tsoil_c,2),153);

pts     = 90; % 90th percentile

for d = 1:153
    tsoil_sample = reshape(tsoil_c(:,:,d+120-7:d+120+7,:),[size(tsoil_c,1) size(tsoil_c,2) 15*30]);
    tsoil_p90(:,:,d)    = prctile(tsoil_sample,pts,3); % 90th percentile
    clear tsoil_sample
    disp(d)
end

tsoil_extrm = tsoil(:,:,121:273,:)>repmat(tsoil_p90,[1 1 1 38]); % identify hot extremes in warm seasons

clear tsoil_c
%**************************************************************************
tsoil_without_ant = reshape(tsoil_without_ant,[size(tsoil_without_ant,1) size(tsoil_without_ant,2) 365 38]);

tsoil_without_ant_c   = tsoil_without_ant(:,:,:,2:31); % 1981-2010, climatology
tsoil_without_ant_p90 = zeros(size(tsoil_without_ant_c,1),size(tsoil_without_ant_c,2),153);

pts     = 90; % 90th percentile

for d = 1:153
    tsoil_without_ant_sample = reshape(tsoil_without_ant_c(:,:,d+120-7:d+120+7,:),[size(tsoil_without_ant_c,1) size(tsoil_without_ant_c,2) 15*30]);
    tsoil_without_ant_p90(:,:,d)    = prctile(tsoil_without_ant_sample,pts,3); % 90th percentile
    clear tsoil_without_ant_sample
    disp(d)
end

tsoil_without_ant_extrm = tsoil_without_ant(:,:,121:273,:)>repmat(tsoil_p90,[1 1 1 38]); % identify hot extremes in warm seasons

clear tsoil_without_ant_c tsoil_without_ant_p90
%--------------------------------------------------------------------------
msoil = reshape(msoil,[size(msoil,1) size(msoil,2) 365 38]);

msoil_c   = msoil(:,:,:,2:31); % 1981-2010, climatology
msoil_p10 = zeros(size(msoil_c,1),size(msoil_c,2),153);

pts     = 10; % 10th percentile

for d = 1:153
    msoil_sample = reshape(msoil_c(:,:,d+120-7:d+120+7,:),[size(msoil_c,1) size(msoil_c,2) 15*30]);
    msoil_p10(:,:,d)    = prctile(msoil_sample,pts,3); % 10th percentile
    clear msoil_sample
    disp(d)
end

msoil_extrm = msoil(:,:,121:273,:)<repmat(msoil_p10,[1 1 1 38]); % identify dry extremes in warm seasons

clear msoil_c 
%--------------------------------------------------------------------------
msoil_without_ant = reshape(msoil_without_ant,[size(msoil_without_ant,1) size(msoil_without_ant,2) 365 38]);

msoil_without_ant_c   = msoil_without_ant(:,:,:,2:31); % 1981-2010, climatology
msoil_without_ant_p10 = zeros(size(msoil_without_ant_c,1),size(msoil_without_ant_c,2),153);

pts     = 10; % 10th percentile

for d = 1:153
    msoil_without_ant_sample = reshape(msoil_without_ant_c(:,:,d+120-7:d+120+7,:),[size(msoil_without_ant_c,1) size(msoil_without_ant_c,2) 15*30]);
    msoil_without_ant_p10(:,:,d)    = prctile(msoil_without_ant_sample,pts,3); % 10th percentile
    clear msoil_without_ant_sample
    disp(d)
end

msoil_without_ant_extrm = msoil_without_ant(:,:,121:273,:)<repmat(msoil_p10,[1 1 1 38]); % identify dry extremes in warm seasons

clear msoil_without_ant_c  msoil_without_ant_p10
%--------------------------------------------------------------------------
lct_missing  = find(num_missing~=0|in~=1|isnan(mdata_model)~=0|isnan(tdata_model)~=0);
lct_valid    = find(num_missing==0&in==1&isnan(mdata_model)==0&isnan(tdata_model)==0);
weight  = cos(pi*lat1d(lct_valid)/180.0);
weights = weight/mean(weight);

comp_extrm1     = tsoil_without_ant_extrm==1&msoil_extrm==1;
comp_extrm_frq1 = squeeze(sum(comp_extrm1,3));
comp_frq_sum1   = sum(comp_extrm_frq1,3);

comp_frq_sum12 = reshape(comp_frq_sum1,[size(comp_frq_sum1,1)*size(comp_frq_sum1,2) 1]);
comp_extrm_frq12 = reshape(comp_extrm_frq1,[size(comp_extrm_frq1,1)*size(comp_extrm_frq1,2) size(comp_extrm_frq1,3)]);
comp_extrm_frq12(lct_missing,:) = NaN;
comp_extrm_reg1  = mean(comp_extrm_frq12(lct_valid,:).*repmat(weights,[1 38]),1);

years   = [1980:2017]';
clear comp_extrm1 comp_extrm_frq1 comp_extrm_frq12 comp_frq_sum1 comp_frq_sum12
%--------------------------------------------------------------------------
comp_extrm2     = tsoil_extrm==1&msoil_without_ant_extrm==1;
comp_extrm_frq2 = squeeze(sum(comp_extrm2,3));
comp_frq_sum2   = sum(comp_extrm_frq2,3);

comp_frq_sum22 = reshape(comp_frq_sum2,[size(comp_frq_sum2,1)*size(comp_frq_sum2,2) 1]);
comp_extrm_frq22 = reshape(comp_extrm_frq2,[size(comp_extrm_frq2,1)*size(comp_extrm_frq2,2) size(comp_extrm_frq2,3)]);
comp_extrm_frq22(lct_missing,:) = NaN;
comp_extrm_reg2  = mean(comp_extrm_frq22(lct_valid,:).*repmat(weights,[1 38]),1);

clear comp_extrm2 comp_extrm_frq2 comp_extrm_frq22 comp_frq_sum2 comp_frq_sum22
%--------------------------------------------------------------------------
comp_extrm0     = tsoil_without_ant_extrm==1&msoil_without_ant_extrm==1;
comp_extrm_frq0 = squeeze(sum(comp_extrm0,3));
comp_frq_sum0   = sum(comp_extrm_frq0,3);

comp_frq_sum02 = reshape(comp_frq_sum0,[size(comp_frq_sum0,1)*size(comp_frq_sum0,2) 1]);
comp_extrm_frq02 = reshape(comp_extrm_frq0,[size(comp_extrm_frq0,1)*size(comp_extrm_frq0,2) size(comp_extrm_frq0,3)]);
comp_extrm_frq02(lct_missing,:) = NaN;
comp_extrm_reg0  = mean(comp_extrm_frq02(lct_valid,:).*repmat(weights,[1 38]),1);

clear comp_extrm0 comp_extrm_frq0 comp_extrm_frq02 comp_frq_sum0 comp_frq_sum02
%--------------------------------------------------------------------------
comp_extrm     = tsoil_extrm==1&msoil_extrm==1;
comp_extrm_frq = squeeze(sum(comp_extrm,3));
comp_frq_sum   = sum(comp_extrm_frq,3);

comp_frq_sum2 = reshape(comp_frq_sum,[size(comp_frq_sum,1)*size(comp_frq_sum,2) 1]);
comp_extrm_frq2 = reshape(comp_extrm_frq,[size(comp_extrm_frq,1)*size(comp_extrm_frq,2) size(comp_extrm_frq,3)]);
comp_extrm_frq2(lct_missing,:) = NaN;
comp_extrm_reg  = mean(comp_extrm_frq2(lct_valid,:).*repmat(weights,[1 38]),1);

clear comp_extrm comp_extrm_frq comp_extrm_frq2 comp_frq_sum comp_frq_sum2

comp_extrm_reg_msoil = comp_extrm_reg1 - comp_extrm_reg0;
comp_extrm_reg_tsoil = comp_extrm_reg2 - comp_extrm_reg0;
comp_extrm_reg_res   = comp_extrm_reg-(comp_extrm_reg_msoil+comp_extrm_reg_tsoil+comp_extrm_reg0);

[comp_extrm_reg0_smoothed] = fLOESS(comp_extrm_reg0',0.75);
[comp_extrm_reg1_smoothed] = fLOESS(comp_extrm_reg1',0.75);
[comp_extrm_reg2_smoothed] = fLOESS(comp_extrm_reg2',0.75);
[comp_extrm_reg_msoil_smoothed] = fLOESS(comp_extrm_reg_msoil',0.75);
[comp_extrm_reg_tsoil_smoothed] = fLOESS(comp_extrm_reg_tsoil',0.75);
[comp_extrm_reg_res_smoothed] = fLOESS(comp_extrm_reg_res',0.75);
% plot(comp_extrm_reg_msoil+comp_extrm_reg_tsoil+comp_extrm_reg0,'r')
% hold on
% plot(comp_extrm_reg,'k')

% b = Theil_Sen_Regress(years,comp_extrm_reg0)
% datain = [years comp_extrm_reg0'];
% [taub tau h sig Z S sigma sen n senplot CIlower CIupper D Dall C3 nsigma] = ktaub(datain, 0.05, 0)

% b = Theil_Sen_Regress(years,comp_extrm_reg_res)
% datain = [years comp_extrm_reg_res'];
% [taub tau h sig Z S sigma sen n senplot CIlower CIupper D Dall C3 nsigma] = ktaub(datain, 0.05, 0)
%**************************************************************************
myncid = netcdf.create('fig4a.nc', 'NC_NOCLOBBER');
dimid1 = netcdf.defDim(myncid,'years',38);
dimid2 = netcdf.defDim(myncid,'stat',2);
varid0 = netcdf.defVar(myncid,'comp_extrm_reg0','double',[dimid1 dimid2]);
varid1 = netcdf.defVar(myncid,'comp_extrm_reg1','double',[dimid1 dimid2]);
varid2 = netcdf.defVar(myncid,'comp_extrm_reg2','double',[dimid1 dimid2]);
varid3 = netcdf.defVar(myncid,'comp_extrm_reg_msoil','double',[dimid1 dimid2]);
varid4 = netcdf.defVar(myncid,'comp_extrm_reg_tsoil','double',[dimid1 dimid2]);
varid5 = netcdf.defVar(myncid,'comp_extrm_reg_res','double',[dimid1 dimid2]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid0, [comp_extrm_reg0' comp_extrm_reg0_smoothed]);
netcdf.putVar(myncid, varid1, [comp_extrm_reg1' comp_extrm_reg1_smoothed]);
netcdf.putVar(myncid, varid2, [comp_extrm_reg2' comp_extrm_reg2_smoothed]);
netcdf.putVar(myncid, varid3, [comp_extrm_reg_msoil' comp_extrm_reg_msoil_smoothed]);
netcdf.putVar(myncid, varid4, [comp_extrm_reg_tsoil' comp_extrm_reg_tsoil_smoothed]);
netcdf.putVar(myncid, varid5, [comp_extrm_reg_res' comp_extrm_reg_res_smoothed]);
netcdf.close(myncid);
