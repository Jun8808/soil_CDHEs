clear all
clc

nc_file = 'H:\WORKS\34-Soil_CDHE\figure2\China_Tsoil_regrid.nc';  % file name
lonT     = ncread(nc_file, 'lon');
latT     = ncread(nc_file, 'lat');
tsoil   = ncread(nc_file, 'Tsoil_regrid');  % soil temperature at 10cm layer

clear nc_file
%--------------------------------------------------------------------------
nc_file = 'H:\WORKS\34-Soil_CDHE\figure2\China_Msoil_regrid.nc';  % file name
lonM     = ncread(nc_file, 'lon');
latM     = ncread(nc_file, 'lat');
msoil    = ncread(nc_file, 'Msoil_regrid');  % soil temperature at 10cm layer

clear nc_file

latM  = latM(end:-1:1);
msoil = msoil(:,end:-1:1,:);
%--------------------------------------------------------------------------
lon = [72.75:0.5:136.75];
lat = [15.75:0.5:54.25];
[lat2d,lon2d]    = meshgrid(lat,lon);
[latT2d,lonT2d]  = meshgrid(latT,lonT);
[latM2d,lonM2d]  = meshgrid(latM,lonM);

for i = 1:size(tsoil,3)
tsoil_regrid(:,:,i) = interp2(latT2d,lonT2d,tsoil(:,:,i),lat2d,lon2d);
disp(i)
end

for i = 1:size(msoil,3)
msoil_regrid(:,:,i) = interp2(latM2d,lonM2d,msoil(:,:,i),lat2d,lon2d);
disp(i)
end

clear tsoil msoil lat2d lon2d latT lonT latM lonM latT2d lonT2d latM2d lonM2d

tsoil = tsoil_regrid;
msoil = msoil_regrid;
clear tsoil_regrid msoil_regrid

num_missing_t = sum(isnan(tsoil),3); % identify grid cells with missing T
num_missing_m = sum(isnan(msoil),3); % identify grid cells with missing M

for j = 1:length(lat)
    for i = 1:length(lon)
        if num_missing_t(i,j)~=0|num_missing_m(i,j)~=0
            tsoil(i,j,:) = NaN;
            msoil(i,j,:) = NaN;
        end
    end
end

num_missing = sum(isnan(tsoil),3); % identify grid cells with missing T
num_missing = reshape(num_missing,[size(num_missing,1)*size(num_missing,2) 1]);
%**************************************************************************
lon2d = repmat(lon',[1 length(lat)]);
lat2d = repmat(lat,[length(lon) 1]);

lon1d = reshape(lon2d,[size(lon2d,1)*size(lon2d,2) 1]);
lat1d = reshape(lat2d,[size(lat2d,1)*size(lat2d,2) 1]);

load H:\WORKS\34-Soil_CDHE\figure2\chngon
stmp=s(2);
load H:\WORKS\34-Soil_CDHE\figure2\chnpatch
s(1).long=stmp.long;
s(1).lat=stmp.lat; 

[in1 on1] = inpolygon(lon1d,lat1d,s(1).long,s(1).lat);
[in2 on2] = inpolygon(lon1d,lat1d,s(2).long,s(2).lat);
[in3 on3] = inpolygon(lon1d,lat1d,s(3).long,s(3).lat);

in = in1|in2|in3|on1|on2|on3;
%**************************************************************************
msoil_all_model = ncread('H:\WORKS\34-Soil_CDHE\figure4\historical_ano.nc','msoil_model');
tsoil_all_model = ncread('H:\WORKS\34-Soil_CDHE\figure4\historical_ano.nc','tsoil_model');

msoil_all_model = mean(msoil_all_model,4);
tsoil_all_model = mean(tsoil_all_model,4);

msoil_all_model = reshape(msoil_all_model,[size(msoil_all_model,1)*size(msoil_all_model,2) size(msoil_all_model,3)]);
tsoil_all_model = reshape(tsoil_all_model,[size(tsoil_all_model,1)*size(tsoil_all_model,2) size(tsoil_all_model,3)]);

msoil_all_ens = ncread('H:\WORKS\34-Soil_CDHE\figure4\historical_ano.nc','msoil_ens');
tsoil_all_ens = ncread('H:\WORKS\34-Soil_CDHE\figure4\historical_ano.nc','tsoil_ens');

msoil_all_ens = reshape(msoil_all_ens,[size(msoil_all_ens,1)*size(msoil_all_ens,2) size(msoil_all_ens,3) size(msoil_all_ens,4)]);
tsoil_all_ens = reshape(tsoil_all_ens,[size(tsoil_all_ens,1)*size(tsoil_all_ens,2) size(tsoil_all_ens,3) size(tsoil_all_ens,4)]);
%**************************************************************************
msoil_nat_model = ncread('H:\WORKS\34-Soil_CDHE\figure4\hist-nat_ano.nc','msoil_model');
tsoil_nat_model = ncread('H:\WORKS\34-Soil_CDHE\figure4\hist-nat_ano.nc','tsoil_model');

msoil_nat_model = mean(msoil_nat_model,4);
tsoil_nat_model = mean(tsoil_nat_model,4);

msoil_nat_model = reshape(msoil_nat_model,[size(msoil_nat_model,1)*size(msoil_nat_model,2) size(msoil_nat_model,3)]);
tsoil_nat_model = reshape(tsoil_nat_model,[size(tsoil_nat_model,1)*size(tsoil_nat_model,2) size(tsoil_nat_model,3)]);

msoil_nat_ens = ncread('H:\WORKS\34-Soil_CDHE\figure4\hist-nat_ano.nc','msoil_ens');
tsoil_nat_ens = ncread('H:\WORKS\34-Soil_CDHE\figure4\hist-nat_ano.nc','tsoil_ens');

msoil_nat_ens = reshape(msoil_nat_ens,[size(msoil_nat_ens,1)*size(msoil_nat_ens,2) size(msoil_nat_ens,3) size(msoil_nat_ens,4)]);
tsoil_nat_ens = reshape(tsoil_nat_ens,[size(tsoil_nat_ens,1)*size(tsoil_nat_ens,2) size(tsoil_nat_ens,3) size(tsoil_nat_ens,4)]);
%**************************************************************************
lct  = find(num_missing==0&in==1&isnan(msoil_all_model(:,1))==0&isnan(tsoil_all_model(:,1))==0);

msoil = reshape(msoil,[size(msoil,1) size(msoil,2) 365 38]);
tsoil = reshape(tsoil,[size(tsoil,1) size(tsoil,2) 365 38]);

msoil_ano = msoil - repmat(mean(msoil(:,:,:,2:31),4),[1 1 1 38]);
tsoil_ano = tsoil - repmat(mean(tsoil(:,:,:,2:31),4),[1 1 1 38]);

msoil_ano = squeeze(mean(msoil_ano(:,:,121:273,:),3));
tsoil_ano = squeeze(mean(tsoil_ano(:,:,121:273,:),3));

msoil_ano = reshape(msoil_ano,[size(msoil_ano,1)*size(msoil_ano,2) 38]);
tsoil_ano = reshape(tsoil_ano,[size(tsoil_ano,1)*size(tsoil_ano,2) 38]);

weight  = cos(pi*lat1d(lct)/180.0);
weights = weight/mean(weight);

msoil_ano_obs  = mean(msoil_ano(lct,:).*repmat(weights,[1 38]));
tsoil_ano_obs  = mean(tsoil_ano(lct,:).*repmat(weights,[1 38]));

clear msoil tsoil msoil_ano tsoil_ano

years   = [1980:2017]';
alpha   = 0.001;
% b = Theil_Sen_Regress(years,tsoil_ano_obs)
% datain = [years tsoil_ano_obs'];
% [taub tau h sig Z S sigma sen n senplot CIlower CIupper D Dall C3 nsigma] = ktaub(datain, 0.05, 0)

% b = Theil_Sen_Regress(years,msoil_ano_obs*100)
% datain = [years msoil_ano_obs'*100];
% [taub tau h sig Z S sigma sen n senplot CIlower CIupper D Dall C3 nsigma] = ktaub(datain, 0.05, 0)
%**************************************************************************
msoil_ano_all_model  = mean(msoil_all_model(lct,:).*repmat(weights,[1 38]));
tsoil_ano_all_model  = mean(tsoil_all_model(lct,:).*repmat(weights,[1 38]));
msoil_ano_nat_model  = mean(msoil_nat_model(lct,:).*repmat(weights,[1 38]));
tsoil_ano_nat_model  = mean(tsoil_nat_model(lct,:).*repmat(weights,[1 38]));

msoil_ano_all_ens  = squeeze(mean(msoil_all_ens(lct,:,:).*repmat(weights,[1 38 40])));
tsoil_ano_all_ens  = squeeze(mean(tsoil_all_ens(lct,:,:).*repmat(weights,[1 38 40])));
msoil_ano_nat_ens  = squeeze(mean(msoil_nat_ens(lct,:,:).*repmat(weights,[1 38 40])));
tsoil_ano_nat_ens  = squeeze(mean(tsoil_nat_ens(lct,:,:).*repmat(weights,[1 38 40])));

clear msoil_all_model tsoil_all_model msoil_nat_model tsoil_nat_model
clear msoil_all_ens tsoil_all_ens msoil_nat_ens tsoil_nat_ens

% b = Theil_Sen_Regress(years,tsoil_ano_all_model)
% datain = [years tsoil_ano_all_model'];
% [taub tau h sig Z S sigma sen n senplot CIlower CIupper D Dall C3 nsigma] = ktaub(datain, 0.05, 0)

% b = Theil_Sen_Regress(years,msoil_ano_all_model)
% datain = [years msoil_ano_all_model'];
% [taub tau h sig Z S sigma sen n senplot CIlower CIupper D Dall C3 nsigma] = ktaub(datain, 0.05, 0)

% b = Theil_Sen_Regress(years,tsoil_ano_nat_model)
% datain = [years tsoil_ano_nat_model'];
% [taub tau h sig Z S sigma sen n senplot CIlower CIupper D Dall C3 nsigma] = ktaub(datain, 0.05, 0)

% b = Theil_Sen_Regress(years,msoil_ano_nat_model)
% datain = [years msoil_ano_nat_model'];
% [taub tau h sig Z S sigma sen n senplot CIlower CIupper D Dall C3 nsigma] = ktaub(datain, 0.05, 0)
%**************************************************************************
myncid = netcdf.create('fig4ab.nc', 'NC_NOCLOBBER');
dimid1 = netcdf.defDim(myncid,'years',length(years));
dimid2 = netcdf.defDim(myncid,'stat',2);
dimid6 = netcdf.defDim(myncid,'lct',length(lct));
varid1 = netcdf.defVar(myncid,'msoil_ano_obs','double',dimid1);
varid2 = netcdf.defVar(myncid,'tsoil_ano_obs','double',dimid1);
varid3 = netcdf.defVar(myncid,'msoil_ano_all_model','double',[dimid1]);
varid4 = netcdf.defVar(myncid,'tsoil_ano_all_model','double',[dimid1]);
varid5 = netcdf.defVar(myncid,'msoil_ano_nat_model','double',[dimid1]);
varid6 = netcdf.defVar(myncid,'tsoil_ano_nat_model','double',[dimid1]);
varid7 = netcdf.defVar(myncid,'msoil_ano_all_ens','double',[dimid1 dimid2]);
varid8 = netcdf.defVar(myncid,'tsoil_ano_all_ens','double',[dimid1 dimid2]);
varid9 = netcdf.defVar(myncid,'msoil_ano_nat_ens','double',[dimid1 dimid2]);
varid10 = netcdf.defVar(myncid,'tsoil_ano_nat_ens','double',[dimid1 dimid2]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid1, msoil_ano_obs);
netcdf.putVar(myncid, varid2, tsoil_ano_obs);
netcdf.putVar(myncid, varid3, msoil_ano_all_model);
netcdf.putVar(myncid, varid4, tsoil_ano_all_model);
netcdf.putVar(myncid, varid5, msoil_ano_nat_model);
netcdf.putVar(myncid, varid6, tsoil_ano_nat_model);
netcdf.putVar(myncid, varid7, [prctile(msoil_ano_all_ens,5,2) prctile(msoil_ano_all_ens,95,2)]);
netcdf.putVar(myncid, varid8, [prctile(tsoil_ano_all_ens,5,2) prctile(tsoil_ano_all_ens,95,2)]);
netcdf.putVar(myncid, varid9, [prctile(msoil_ano_nat_ens,5,2) prctile(msoil_ano_nat_ens,95,2)]);
netcdf.putVar(myncid, varid10, [prctile(tsoil_ano_nat_ens,5,2) prctile(tsoil_ano_nat_ens,95,2)]);
netcdf.close(myncid);




















