clear all
clc

lati = ncread('H:\WORKS\34-Soil_CDHE\figure3\E_regrid.nc','lat');
loni = ncread('H:\WORKS\34-Soil_CDHE\figure3\E_regrid.nc','lon');

lon = [72.75:0.5:136.75];
lat = [15.75:0.5:54.25];
[lat2d,lon2d]      = meshgrid(lat,lon);
[lati_2d,loni_2d]  = meshgrid(lati,loni);

E    = ncread('H:\WORKS\34-Soil_CDHE\figure3\E_regrid.nc','E');
for i = 1:size(E,3)
E_regrid(:,:,i)  = interp2(lati_2d,loni_2d,E(:,:,i),lat2d,lon2d);
disp(i)
end
clear E
E  = E_regrid;
clear E_regrid

Ep   = ncread('H:\WORKS\34-Soil_CDHE\figure3\Ep_regrid.nc','Ep');
for i = 1:size(Ep,3)
Ep_regrid(:,:,i) = interp2(lati_2d,loni_2d,Ep(:,:,i),lat2d,lon2d);
disp(i)
end
clear Ep
Ep = Ep_regrid;
clear Ep_regrid

H    = ncread('H:\WORKS\34-Soil_CDHE\figure3\H_regrid.nc','H');
for i = 1:size(H,3)
H_regrid(:,:,i)  = interp2(lati_2d,loni_2d,H(:,:,i),lat2d,lon2d);
disp(i)
end
clear H
H  = H_regrid;
clear H_regrid
%**************************************************************************
E  = reshape(E,[size(E,1) size(E,2) 365 size(E,3)/365]);     % unit: mm/day
Ep = reshape(Ep,[size(Ep,1) size(Ep,2) 365 size(Ep,3)/365]); % unit: mm/day
H  = reshape(H,[size(H,1) size(H,2) 365 size(H,3)/365]);     % unit: W/m2

Ld = 2.5*10^6; % unit: J/kg
Hp = H - Ld*(Ep-E)/(24*3600); % (J/kg)*(mm/s) = W/m2

%plot(squeeze(E(100,74,:,end)))
clear E Ep
%**************************************************************************
nc_file = 'H:\WORKS\34-Soil_CDHE\figure2\China_Tsoil_regrid.nc';  % file name
% ncdisp(nc_file)
lonT     = ncread(nc_file, 'lon');
latT     = ncread(nc_file, 'lat');
tsoil   = ncread(nc_file, 'Tsoil_regrid');  % soil temperature at 10cm layer
[latT2d,lonT2d]  = meshgrid(latT,lonT);
clear nc_file

for i = 1:size(tsoil,3)
tsoil_regrid(:,:,i) = interp2(latT2d,lonT2d,tsoil(:,:,i),lat2d,lon2d);
disp(i)
end  
clear tsoil
tsoil = tsoil_regrid;
clear tsoil_regrid

tsoil  = reshape(tsoil,[size(tsoil,1) size(tsoil,2) 365 size(tsoil,3)/365]);
%**************************************************************************
H_ano     = (H - repmat(mean(H(:,:,:,2:31),4),[1 1 1 38]))./repmat(std(H(:,:,:,2:31),0,4),[1 1 1 38]);
Hp_ano    = (Hp - repmat(mean(Hp(:,:,:,2:31),4),[1 1 1 38]))./repmat(std(Hp(:,:,:,2:31),0,4),[1 1 1 38]);
tsoil_ano = (tsoil - repmat(mean(tsoil(:,:,:,2:31),4),[1 1 1 38]))./repmat(std(tsoil(:,:,:,2:31),0,4),[1 1 1 38]);

H_ano     = reshape(H_ano(:,:,121:273,:),[size(H_ano,1) size(H_ano,2) 153*38]);
Hp_ano    = reshape(Hp_ano(:,:,121:273,:),[size(Hp_ano,1) size(Hp_ano,2) 153*38]);
tsoil_ano = reshape(tsoil_ano(:,:,121:273,:),[size(tsoil_ano,1) size(tsoil_ano,2) 153*38]);

small_pi  = (H_ano-Hp_ano).*tsoil_ano;

small_pi2 = squeeze(mean(reshape(small_pi,[size(small_pi,1) size(small_pi,2) 153 size(small_pi,3)/153]),3));

years = [1980:2017]';
alpha = 0.05;

for j = 1:size(small_pi2,2)
    for i = 1:size(small_pi2,1)

        if sum(isnan(small_pi2(i,j,:)))==0
           b = Theil_Sen_Regress(years,squeeze(small_pi2(i,j,:)));
           [H,p_value] = Mann_Kendall(squeeze(small_pi2(i,j,:)),alpha);  
           small_pi_trd(i,j) = b*10;
           small_pi_trd_sig(i,j) = H;
        else
           small_pi_trd(i,j) = NaN;
           small_pi_trd_sig(i,j) = 0;
        end
    end
    disp(j)
end

big_pi    = mean(small_pi,3);
%**************************************************************************
lon1d = reshape(lon2d,[size(lon2d,1)*size(lon2d,2) 1]);
lat1d = reshape(lat2d,[size(lat2d,1)*size(lat2d,2) 1]);

load H:\WORKS\34-Soil_CDHE\figure2\chngon
stmp=s(2);
load H:\WORKS\34-Soil_CDHE\figure2\chnpatch
s(1).long=stmp.long;
s(1).lat=stmp.lat; 

[in1 on1] = inpolygon(lon1d,lat1d,s(1).long,s(1).lat);
[in2 on2] = inpolygon(lon1d,lat1d,s(2).long,s(2).lat);
[in3 on3] = inpolygon(lon1d,lat1d,s(3).long,s(3).lat);

in = in1|in2|in3|on1|on2|on3;


small_pi_trd(find(in==0)) = NaN;
small_pi_trd(find(isnan(small_pi_trd)==1)) = -999;
lct = find(small_pi_trd_sig==1);
lonsig = lon1d(lct);
latsig = lat1d(lct);

big_pi(find(in==0)) = NaN;
big_pi(find(isnan(big_pi)==1)) = -999;
%**************************************************************************
myncid = netcdf.create('fig3b.nc', 'NC_NOCLOBBER');
dimid1 = netcdf.defDim(myncid,'lon',length(lon));
dimid2 = netcdf.defDim(myncid,'lat',length(lat));
dimid3 = netcdf.defDim(myncid,'sig',length(latsig));
varid1 = netcdf.defVar(myncid,'lon','double',dimid1);
varid2 = netcdf.defVar(myncid,'lat','double',dimid2);
varid3 = netcdf.defVar(myncid,'big_pi','double',[dimid1 dimid2]);
varid4 = netcdf.defVar(myncid,'small_pi_trd','double',[dimid1 dimid2]);
varid5 = netcdf.defVar(myncid,'lonsig','double',[dimid3]);
varid6 = netcdf.defVar(myncid,'latsig','double',[dimid3]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid1, lon);
netcdf.putVar(myncid, varid2, lat);
netcdf.putVar(myncid, varid3, big_pi);
netcdf.putVar(myncid, varid4, small_pi_trd);
netcdf.putVar(myncid, varid5, lonsig);
netcdf.putVar(myncid, varid6, latsig);
netcdf.reDef(myncid);
netcdf.putAtt(myncid, varid1,'units','degrees_north');
netcdf.putAtt(myncid, varid2,'units','degrees_east');
netcdf.close(myncid);


