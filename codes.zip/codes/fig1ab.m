clear all
clc

nc_file = 'H:\WORKS\34-Soil_CDHE\figure1\SIF.nc';  % file name
% ncdisp(nc_file)
lons    = ncread(nc_file, 'lon');
lats    = ncread(nc_file, 'lat');
sif     = ncread(nc_file, 'sif');  % gpp
%contourf(mean(mean(sif,4),3))
clear nc_file
%--------------------------------------------------------------------------
nc_file = 'H:\WORKS\34-Soil_CDHE\figure1\GPP.nc';  % file name
% ncdisp(nc_file)
long    = ncread(nc_file, 'lon');
latg    = ncread(nc_file, 'lat');
gpp     = ncread(nc_file, 'GPP');  % gpp
clear nc_file
% data have errors in days of 481 and 482
gpp(:,:,481) = gpp(:,:,480)+(gpp(:,:,480)-gpp(:,:,483))/3.0;
gpp(:,:,482) = gpp(:,:,480)+2.0*(gpp(:,:,480)-gpp(:,:,483))/3.0;
%plot(squeeze(sum(sum(isnan(gpp(:,:,1:500)),1),2)))
%contourf(mean(mean(gpp,4),3))
%--------------------------------------------------------------------------
nc_file = 'H:\WORKS\34-Soil_CDHE\figure2\China_Tsoil_regrid.nc';  % file name
% ncdisp(nc_file)
lonT     = ncread(nc_file, 'lon');
latT     = ncread(nc_file, 'lat');
tsoil   = ncread(nc_file, 'Tsoil_regrid');  % soil temperature at 10cm layer

clear nc_file
%--------------------------------------------------------------------------
nc_file = 'H:\WORKS\34-Soil_CDHE\figure2\China_Msoil_regrid.nc';  % file name
% ncdisp(nc_file)
lonM     = ncread(nc_file, 'lon');
latM     = ncread(nc_file, 'lat');
msoil    = ncread(nc_file, 'Msoil_regrid');  % soil temperature at 10cm layer

clear nc_file

latM  = latM(end:-1:1);
msoil = msoil(:,end:-1:1,:);
%--------------------------------------------------------------------------
lon = [72.75:0.5:136.75];
lat = [15.75:0.5:54.25];
[lat2d,lon2d]    = meshgrid(lat,lon);
[latT2d,lonT2d]  = meshgrid(latT,lonT);
[latM2d,lonM2d]  = meshgrid(latM,lonM);

for i = 1:size(tsoil,3)
tsoil_regrid(:,:,i) = interp2(latT2d,lonT2d,tsoil(:,:,i),lat2d,lon2d);
disp(i)
end

for i = 1:size(msoil,3)
msoil_regrid(:,:,i) = interp2(latM2d,lonM2d,msoil(:,:,i),lat2d,lon2d);
disp(i)
end
%contourf(sum(isnan(tsoil),3))

clear tsoil msoil lat2d lon2d latT lonT latM lonM latT2d lonT2d latM2d lonM2d

tsoil = tsoil_regrid;
msoil = msoil_regrid;
clear tsoil_regrid msoil_regrid

num_missing_t = sum(isnan(tsoil),3); % identify grid cells with missing T
num_missing_m = sum(isnan(msoil),3); % identify grid cells with missing M

for j = 1:length(lat)
    for i = 1:length(lon)
        if num_missing_t(i,j)~=0|num_missing_m(i,j)~=0
            tsoil(i,j,:) = NaN;
            msoil(i,j,:) = NaN;
        end
    end
end
%--------------------------------------------------------------------------
tsoil  = reshape(tsoil,[size(tsoil,1) size(tsoil,2) 365 size(tsoil,3)/365]);
msoil  = reshape(msoil,[size(msoil,1) size(msoil,2) 365 size(msoil,3)/365]);
% sif    = reshape(sif,[size(sif,1) size(sif,2) 365 size(sif,3)/365]);
gpp    = reshape(gpp,[size(gpp,1) size(gpp,2) 365 size(gpp,3)/365]);

sif    = sif(:,:,121:273,:);
gpp    = gpp(:,:,61:213,:); % data are from March 
%--------------------------------------------------------------------------
data = xlsread('monthly_in_situ_co2_mlo.csv');
co2_mon  = data(505:720,5);
co2_mon  = reshape(co2_mon,[12 size(co2_mon,1)/12]);
co2_daily = zeros([size(sif,3) size(sif,4)]);
co2_daily(1:31,:)    = repmat(co2_mon(5,:),[31 1]);
co2_daily(32:61,:)   = repmat(co2_mon(6,:),[30 1]);
co2_daily(62:92,:)   = repmat(co2_mon(7,:),[31 1]);
co2_daily(93:123,:)  = repmat(co2_mon(8,:),[31 1]);
co2_daily(124:153,:) = repmat(co2_mon(9,:),[30 1]);

sif_detrend     = zeros(size(sif))*NaN;
gpp_detrend     = zeros(size(gpp))*NaN;
for d = 1:size(sif,3)
for j = 1:size(sif,2)
    for i = 1:size(sif,1)
        b = polyfit(co2_daily(d,:),squeeze(sif(i,j,d,:)),1);
        sif_detrend(i,j,d,:) = squeeze(sif(i,j,d,:))-b(1)*(co2_daily(d,:)'-co2_daily(d,1));
        clear b
        b = polyfit(co2_daily(d,:),squeeze(gpp(i,j,d,:)),1);
        gpp_detrend(i,j,d,:) = squeeze(gpp(i,j,d,:))-b(1)*(co2_daily(d,:)'-co2_daily(d,1));
        clear b
    end
end
disp(d)
end

sif_ano_detrend = sif_detrend-repmat(mean(sif_detrend,4),[1 1 1 18]);
gpp_ano_detrend = gpp_detrend-repmat(mean(gpp_detrend,4),[1 1 1 18]);

sif_ano_detrend = reshape(sif_ano_detrend,[size(sif_ano_detrend,1) size(sif_ano_detrend,2) size(sif_ano_detrend,3)*size(sif_ano_detrend,4)]);
gpp_ano_detrend = reshape(gpp_ano_detrend,[size(gpp_ano_detrend,1) size(gpp_ano_detrend,2) size(gpp_ano_detrend,3)*size(gpp_ano_detrend,4)]);

% plot(squeeze(sif_ano(50,70,1,:)))
% hold on
% plot(squeeze(sif_ano_detrend(50,70,1,:)))
% 
% plot(squeeze(gpp_ano(50,70,1,:)))
% hold on
% plot(squeeze(gpp_ano_detrend(50,70,1,:)))
%--------------------------------------------------------------------------        
tsoil_c   = tsoil(:,:,:,2:31); % 1981-2010, climatology
tsoil_p90 = zeros(size(tsoil_c,1),size(tsoil_c,2),153);

pts     = 90; % 90th percentile

for d = 1:153
    tsoil_sample = reshape(tsoil_c(:,:,d+120-7:d+120+7,:),[size(tsoil_c,1) size(tsoil_c,2) 15*30]);
    tsoil_p90(:,:,d)    = prctile(tsoil_sample,pts,3); % 90th percentile
    clear tsoil_sample
    disp(d)
end

tsoil_extrm = tsoil(:,:,121:273,:)>repmat(tsoil_p90,[1 1 1 38]); % identify hot extremes in warm seasons
tsoil_extrm_frq = squeeze(sum(tsoil_extrm,3));                   % calculate annual frequency in warm seasons
clear tsoil_c 
%--------------------------------------------------------------------------
msoil = reshape(msoil,[size(msoil,1) size(msoil,2) 365 38]);

msoil_c   = msoil(:,:,:,2:31); % 1981-2010, climatology
msoil_p10 = zeros(size(msoil_c,1),size(msoil_c,2),153);

pts     = 10; % 10th percentile

for d = 1:153
    msoil_sample = reshape(msoil_c(:,:,d+120-7:d+120+7,:),[size(msoil_c,1) size(msoil_c,2) 15*30]);
    msoil_p10(:,:,d)    = prctile(msoil_sample,pts,3); % 10th percentile
    clear msoil_sample
    disp(d)
end

msoil_extrm = msoil(:,:,121:273,:)<repmat(msoil_p10,[1 1 1 38]); % identify dry extremes in warm seasons
msoil_extrm_frq = squeeze(sum(msoil_extrm,3));
clear msoil_c
%--------------------------------------------------------------------------
comp_extrm = tsoil_extrm==1&msoil_extrm==1;
comp_extrm = comp_extrm(:,:,:,21:end); % 2000-2017
comp_extrm      = reshape(comp_extrm,[size(comp_extrm,1) size(comp_extrm,2) size(comp_extrm,3)*size(comp_extrm,4)]);

sif_ano_detrend_compsite = zeros([length(lon) length(lat)])*NaN;
gpp_ano_detrend_compsite = zeros([length(lon) length(lat)])*NaN;

for j = 1:length(lat)
    for i = 1:length(lon)
        lct = find(comp_extrm(i,j,:)==1);
        if length(lct)~=0
            sif_ano_detrend_compsite(i,j) = mean(sif_ano_detrend(i,j,lct),'omitnan');
            gpp_ano_detrend_compsite(i,j) = mean(gpp_ano_detrend(i,j,lct),'omitnan');
        end
    end
end

lon2d = repmat(lon',[1 length(lat)]);
lat2d = repmat(lat,[length(lon) 1]);

lon1d = reshape(lon2d,[size(lon2d,1)*size(lon2d,2) 1]);
lat1d = reshape(lat2d,[size(lat2d,1)*size(lat2d,2) 1]);

load H:\WORKS\34-Soil_CDHE\figure2\chngon
stmp=s(2);
load H:\WORKS\34-Soil_CDHE\figure2\chnpatch
s(1).long=stmp.long;
s(1).lat=stmp.lat; 

[in1 on1] = inpolygon(lon1d,lat1d,s(1).long,s(1).lat);
[in2 on2] = inpolygon(lon1d,lat1d,s(2).long,s(2).lat);
[in3 on3] = inpolygon(lon1d,lat1d,s(3).long,s(3).lat);

in = in1|in2|in3|on1|on2|on3;

sif_ano_detrend_compsite(find(in==0)) = NaN;
gpp_ano_detrend_compsite(find(in==0)) = NaN;

%contourf(sif_ano_detrend_compsite')
%contourf(gpp_ano_detrend_compsite')
sif_ano_detrend_compsite(find(isnan(sif_ano_detrend_compsite)==1)) = -999;
gpp_ano_detrend_compsite(find(isnan(gpp_ano_detrend_compsite)==1)) = -999;
%**************************************************************************
myncid = netcdf.create('fig1ab.nc', 'NC_NOCLOBBER');
dimid1 = netcdf.defDim(myncid,'lon',length(lon));
dimid2 = netcdf.defDim(myncid,'lat',length(lat));
varid1 = netcdf.defVar(myncid,'lon','double',dimid1);
varid2 = netcdf.defVar(myncid,'lat','double',dimid2);
varid3 = netcdf.defVar(myncid,'sif_ano_detrend_compsite','double',[dimid1 dimid2]);
varid4 = netcdf.defVar(myncid,'gpp_ano_detrend_compsite','double',[dimid1 dimid2]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid1, lon);
netcdf.putVar(myncid, varid2, lat);
netcdf.putVar(myncid, varid3, sif_ano_detrend_compsite);
netcdf.putVar(myncid, varid4, gpp_ano_detrend_compsite);
netcdf.reDef(myncid);
netcdf.putAtt(myncid, varid1,'units','degrees_north');
netcdf.putAtt(myncid, varid2,'units','degrees_east');
netcdf.close(myncid);



