clear all
clc

nc_file = 'H:\WORKS\34-Soil_CDHE\figure1\SIF.nc';  % file name
% ncdisp(nc_file)
lons    = ncread(nc_file, 'lon');
lats    = ncread(nc_file, 'lat');
sif     = ncread(nc_file, 'sif');  % gpp
%contourf(mean(mean(sif,4),3))
clear nc_file
%--------------------------------------------------------------------------
nc_file = 'H:\WORKS\34-Soil_CDHE\figure1\GPP.nc';  % file name
% ncdisp(nc_file)
long    = ncread(nc_file, 'lon');
latg    = ncread(nc_file, 'lat');
gpp     = ncread(nc_file, 'GPP');  % gpp
clear nc_file
% data have errors in days of 481 and 482
gpp(:,:,481) = gpp(:,:,480)+(gpp(:,:,480)-gpp(:,:,483))/3.0;
gpp(:,:,482) = gpp(:,:,480)+2.0*(gpp(:,:,480)-gpp(:,:,483))/3.0;
%plot(squeeze(sum(sum(isnan(gpp(:,:,1:500)),1),2)))
%contourf(mean(mean(gpp,4),3))
%--------------------------------------------------------------------------
nc_file = 'H:\WORKS\34-Soil_CDHE\figure2\China_Tsoil_regrid.nc';  % file name
% ncdisp(nc_file)
lonT     = ncread(nc_file, 'lon');
latT     = ncread(nc_file, 'lat');
tsoil   = ncread(nc_file, 'Tsoil_regrid');  % soil temperature at 10cm layer

clear nc_file
%--------------------------------------------------------------------------
nc_file = 'H:\WORKS\34-Soil_CDHE\figure2\China_Msoil_regrid.nc';  % file name
% ncdisp(nc_file)
lonM     = ncread(nc_file, 'lon');
latM     = ncread(nc_file, 'lat');
msoil    = ncread(nc_file, 'Msoil_regrid');  % soil temperature at 10cm layer

clear nc_file

latM  = latM(end:-1:1);
msoil = msoil(:,end:-1:1,:);
%--------------------------------------------------------------------------
lon = [72.75:0.5:136.75];
lat = [15.75:0.5:54.25];
[lat2d,lon2d]    = meshgrid(lat,lon);
[latT2d,lonT2d]  = meshgrid(latT,lonT);
[latM2d,lonM2d]  = meshgrid(latM,lonM);

for i = 1:size(tsoil,3)
tsoil_regrid(:,:,i) = interp2(latT2d,lonT2d,tsoil(:,:,i),lat2d,lon2d);
disp(i)
end

for i = 1:size(msoil,3)
msoil_regrid(:,:,i) = interp2(latM2d,lonM2d,msoil(:,:,i),lat2d,lon2d);
disp(i)
end
%contourf(sum(isnan(tsoil),3))

clear tsoil msoil lat2d lon2d latT lonT latM lonM latT2d lonT2d latM2d lonM2d

tsoil = tsoil_regrid;
msoil = msoil_regrid;
clear tsoil_regrid msoil_regrid

num_missing_t = sum(isnan(tsoil),3); % identify grid cells with missing T
num_missing_m = sum(isnan(msoil),3); % identify grid cells with missing M

for j = 1:length(lat)
    for i = 1:length(lon)
        if num_missing_t(i,j)~=0|num_missing_m(i,j)~=0
            tsoil(i,j,:) = NaN;
            msoil(i,j,:) = NaN;
        end
    end
end
%--------------------------------------------------------------------------
tsoil  = reshape(tsoil,[size(tsoil,1) size(tsoil,2) 365 size(tsoil,3)/365]);
msoil  = reshape(msoil,[size(msoil,1) size(msoil,2) 365 size(msoil,3)/365]);
% sif    = reshape(sif,[size(sif,1) size(sif,2) 365 size(sif,3)/365]);
gpp    = reshape(gpp,[size(gpp,1) size(gpp,2) 365 size(gpp,3)/365]);

sif    = sif(:,:,121:273,:);
gpp    = gpp(:,:,61:213,:); % data are from March 
%--------------------------------------------------------------------------
data = xlsread('monthly_in_situ_co2_mlo.csv');
co2_mon  = data(505:720,5);
co2_mon  = reshape(co2_mon,[12 size(co2_mon,1)/12]);
co2_daily = zeros([size(sif,3) size(sif,4)]);
co2_daily(1:31,:)    = repmat(co2_mon(5,:),[31 1]);
co2_daily(32:61,:)   = repmat(co2_mon(6,:),[30 1]);
co2_daily(62:92,:)   = repmat(co2_mon(7,:),[31 1]);
co2_daily(93:123,:)  = repmat(co2_mon(8,:),[31 1]);
co2_daily(124:153,:) = repmat(co2_mon(9,:),[30 1]);

sif_detrend     = zeros(size(sif))*NaN;
gpp_detrend     = zeros(size(gpp))*NaN;
for d = 1:size(sif,3)
for j = 1:size(sif,2)
    for i = 1:size(sif,1)
        b = polyfit(co2_daily(d,:),squeeze(sif(i,j,d,:)),1);
        sif_detrend(i,j,d,:) = squeeze(sif(i,j,d,:))-b(1)*(co2_daily(d,:)'-co2_daily(d,1));
        clear b
        b = polyfit(co2_daily(d,:),squeeze(gpp(i,j,d,:)),1);
        gpp_detrend(i,j,d,:) = squeeze(gpp(i,j,d,:))-b(1)*(co2_daily(d,:)'-co2_daily(d,1));
        clear b
    end
end
disp(d)
end

sif_ano_detrend = sif_detrend-repmat(mean(sif_detrend,4),[1 1 1 18]);
gpp_ano_detrend = gpp_detrend-repmat(mean(gpp_detrend,4),[1 1 1 18]);

sif_ano_detrend = reshape(sif_ano_detrend,[size(sif_ano_detrend,1) size(sif_ano_detrend,2) size(sif_ano_detrend,3)*size(sif_ano_detrend,4)]);
gpp_ano_detrend = reshape(gpp_ano_detrend,[size(gpp_ano_detrend,1) size(gpp_ano_detrend,2) size(gpp_ano_detrend,3)*size(gpp_ano_detrend,4)]);
%--------------------------------------------------------------------------
tsoil_c   = tsoil(:,:,:,2:31); % 1981-2010, climatology
msoil = reshape(msoil,[size(msoil,1) size(msoil,2) 365 38]);
msoil_c   = msoil(:,:,:,2:31); % 1981-2010, climatology

pts     = [0:10:100]; % percentiles

sif_ano_detrend_compsite = zeros([length(pts)-1 length(pts)-1 length(lon) length(lat)])*NaN;
gpp_ano_detrend_compsite = zeros([length(pts)-1 length(pts)-1 length(lon) length(lat)])*NaN;


for p = 1:length(pts)
    for d = 1:153
        tsoil_sample = reshape(tsoil_c(:,:,d+120-7:d+120+7,:),[size(tsoil_c,1) size(tsoil_c,2) 15*30]);
        tsoil_pts(:,:,d,p)    = prctile(tsoil_sample,pts(p),3); % percentile
        clear tsoil_sample
    end

    for d = 1:153
        msoil_sample = reshape(msoil_c(:,:,d+120-7:d+120+7,:),[size(msoil_c,1) size(msoil_c,2) 15*30]);
        msoil_pts(:,:,d,p)    = prctile(msoil_sample,pts(p),3); % percentile
        clear msoil_sample
    end
    disp(p)
end


for j = 1:length(lat)
    for i = 1:length(lon)
        for yp = 1:length(pts)-1
            for xp = 1:length(pts)-1

            tsoil_extrm = squeeze(tsoil(i,j,121:273,:))>repmat(squeeze(tsoil_pts(i,j,:,xp)),[1 38])&squeeze(tsoil(i,j,121:273,:))<=repmat(squeeze(tsoil_pts(i,j,:,xp+1)),[1 38]);
            msoil_extrm = squeeze(msoil(i,j,121:273,:))>repmat(squeeze(msoil_pts(i,j,:,yp)),[1 38])&squeeze(msoil(i,j,121:273,:))<=repmat(squeeze(msoil_pts(i,j,:,yp+1)),[1 38]); 

            comp_extrm = tsoil_extrm==1&msoil_extrm==1;
            comp_extrm = comp_extrm(:,21:end); % 2000-2017
            comp_extrm = reshape(comp_extrm,[size(comp_extrm,1)*size(comp_extrm,2) 1]);

            lct = find(comp_extrm==1);
            sif_ano_detrend_compsite(xp,yp,i,j) = mean(sif_ano_detrend(i,j,lct),'omitnan');
            gpp_ano_detrend_compsite(xp,yp,i,j) = mean(gpp_ano_detrend(i,j,lct),'omitnan');

            clear tsoil_extrm msoil_extrm comp_extrm lct
            end
        end
    end
disp(j)
end
save('sif_ano_detrend_compsite.mat','sif_ano_detrend_compsite')
save('gpp_ano_detrend_compsite.mat','gpp_ano_detrend_compsite')
%**************************************************************************
lon2d = repmat(lon',[1 length(lat)]);
lat2d = repmat(lat,[length(lon) 1]);

lon1d = reshape(lon2d,[size(lon2d,1)*size(lon2d,2) 1]);
lat1d = reshape(lat2d,[size(lat2d,1)*size(lat2d,2) 1]);

load H:\WORKS\34-Soil_CDHE\figure2\chngon
stmp=s(2);
load H:\WORKS\34-Soil_CDHE\figure2\chnpatch
s(1).long=stmp.long;
s(1).lat=stmp.lat; 

[in1 on1] = inpolygon(lon1d,lat1d,s(1).long,s(1).lat);
[in2 on2] = inpolygon(lon1d,lat1d,s(2).long,s(2).lat);
[in3 on3] = inpolygon(lon1d,lat1d,s(3).long,s(3).lat);

in = in1|in2|in3|on1|on2|on3;

sif_ano_detrend_compsite = reshape(sif_ano_detrend_compsite,[length(pts)-1 length(pts)-1 length(lon)*length(lat)]);
gpp_ano_detrend_compsite = reshape(gpp_ano_detrend_compsite,[length(pts)-1 length(pts)-1 length(lon)*length(lat)]);

sif_ano_detrend_compsite(:,:,find(in==0)) = NaN;
gpp_ano_detrend_compsite(:,:,find(in==0)) = NaN;

sif_ano_detrend_compsite_p90_p10 = reshape(sif_ano_detrend_compsite(10,1,:),[length(lon) length(lat)]);
gpp_ano_detrend_compsite_p90_p10 = reshape(gpp_ano_detrend_compsite(10,1,:),[length(lon) length(lat)]);

sif_ano_detrend_compsite_p90_p10(find(isnan(sif_ano_detrend_compsite_p90_p10)==1)) = -999;
gpp_ano_detrend_compsite_p90_p10(find(isnan(gpp_ano_detrend_compsite_p90_p10)==1)) = -999;
%--------------------------------------------------------------------------
sif_ano_detrend_compsite_mean = mean(sif_ano_detrend_compsite,3,'omitnan');
gpp_ano_detrend_compsite_mean = mean(gpp_ano_detrend_compsite,3,'omitnan');
%**************************************************************************
myncid = netcdf.create('fig1de.nc', 'NC_NOCLOBBER');
dimid1 = netcdf.defDim(myncid,'xp',length(pts)-1);
dimid2 = netcdf.defDim(myncid,'yp',length(pts)-1);
dimid3 = netcdf.defDim(myncid,'lon',length(lon));
dimid4 = netcdf.defDim(myncid,'lat',length(lat));
varid1 = netcdf.defVar(myncid,'sif_ano_detrend_compsite','double',[dimid1 dimid2]);
varid2 = netcdf.defVar(myncid,'gpp_ano_detrend_compsite','double',[dimid1 dimid2]);
varid3 = netcdf.defVar(myncid,'lon','double',dimid3);
varid4 = netcdf.defVar(myncid,'lat','double',dimid4);
varid5 = netcdf.defVar(myncid,'sif_ano_detrend_compsite_p90_p10','double',[dimid3 dimid4]);
varid6 = netcdf.defVar(myncid,'gpp_ano_detrend_compsite_p90_p10','double',[dimid3 dimid4]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid1, sif_ano_detrend_compsite_mean);
netcdf.putVar(myncid, varid2, gpp_ano_detrend_compsite_mean);
netcdf.putVar(myncid, varid3, lon);
netcdf.putVar(myncid, varid4, lat);
netcdf.putVar(myncid, varid5, sif_ano_detrend_compsite_p90_p10);
netcdf.putVar(myncid, varid6, gpp_ano_detrend_compsite_p90_p10);
netcdf.reDef(myncid);
netcdf.putAtt(myncid, varid3,'units','degrees_north');
netcdf.putAtt(myncid, varid4,'units','degrees_east');
netcdf.close(myncid);


