clear all
clc
nc_file  = 'H:\WORKS\34-Soil_CDHE\figure2\China_Tsoil_regrid.nc';  % file name
lonT     = ncread(nc_file, 'lon');
latT     = ncread(nc_file, 'lat');
tsoil    = ncread(nc_file, 'Tsoil_regrid');  % soil temperature at 10cm layer

clear nc_file
%--------------------------------------------------------------------------
nc_file  = 'H:\WORKS\34-Soil_CDHE\figure2\China_Msoil_regrid.nc';  % file name
lonM     = ncread(nc_file, 'lon');
latM     = ncread(nc_file, 'lat');
msoil    = ncread(nc_file, 'Msoil_regrid');  % soil temperature at 10cm layer

clear nc_file

latM  = latM(end:-1:1);
msoil = msoil(:,end:-1:1,:);
%--------------------------------------------------------------------------
lon = [72.75:0.5:136.75];
lat = [15.75:0.5:54.25];
[lat2d,lon2d]    = meshgrid(lat,lon);
[latT2d,lonT2d]  = meshgrid(latT,lonT);
[latM2d,lonM2d]  = meshgrid(latM,lonM);

for i = 1:size(tsoil,3)
tsoil_regrid(:,:,i) = interp2(latT2d,lonT2d,tsoil(:,:,i),lat2d,lon2d);
disp(i)
end

for i = 1:size(msoil,3)
msoil_regrid(:,:,i) = interp2(latM2d,lonM2d,msoil(:,:,i),lat2d,lon2d);
disp(i)
end

clear tsoil msoil lat2d lon2d latT lonT latM lonM latT2d lonT2d latM2d lonM2d

tsoil = tsoil_regrid;
msoil = msoil_regrid;
clear tsoil_regrid msoil_regrid

num_missing_t = sum(isnan(tsoil),3); % identify grid cells with missing T
num_missing_m = sum(isnan(msoil),3); % identify grid cells with missing M

for j = 1:length(lat)
    for i = 1:length(lon)
        if num_missing_t(i,j)~=0|num_missing_m(i,j)~=0
            tsoil(i,j,:) = NaN;
            msoil(i,j,:) = NaN;
        end
    end
end
%--------------------------------------------------------------------------
tsoil = reshape(tsoil,[size(tsoil,1) size(tsoil,2) 365 38]);

tsoil_c   = tsoil(:,:,:,2:31); % 1981-2010, climatology
tsoil_p90 = zeros(size(tsoil_c,1),size(tsoil_c,2),153);

pts     = 90; % 90th percentile

for d = 1:153
    tsoil_sample = reshape(tsoil_c(:,:,d+120-7:d+120+7,:),[size(tsoil_c,1) size(tsoil_c,2) 15*30]);
    tsoil_p90(:,:,d)    = prctile(tsoil_sample,pts,3); % 90th percentile
    clear tsoil_sample
    disp(d)
end

tsoil_extrm = tsoil(:,:,121:273,:)>repmat(tsoil_p90,[1 1 1 38]); % identify hot extremes in warm seasons
tsoil_extrm_frq = squeeze(sum(tsoil_extrm,3));                   % calculate annual frequency in warm seasons

clear tsoil_c 
%--------------------------------------------------------------------------
msoil = reshape(msoil,[size(msoil,1) size(msoil,2) 365 38]);

msoil_c   = msoil(:,:,:,2:31); % 1981-2010, climatology
msoil_p10 = zeros(size(msoil_c,1),size(msoil_c,2),153);

pts     = 10; % 10th percentile

for d = 1:153
    msoil_sample = reshape(msoil_c(:,:,d+120-7:d+120+7,:),[size(msoil_c,1) size(msoil_c,2) 15*30]);
    msoil_p10(:,:,d)    = prctile(msoil_sample,pts,3); % 10th percentile
    clear msoil_sample
    disp(d)
end

msoil_extrm = msoil(:,:,121:273,:)<repmat(msoil_p10,[1 1 1 38]); % identify dry extremes in warm seasons
msoil_extrm_frq = squeeze(sum(msoil_extrm,3));

clear msoil_c
%--------------------------------------------------------------------------
comp_extrm = tsoil_extrm==1&msoil_extrm==1;
comp_extrm_frq = squeeze(sum(comp_extrm,3));
%--------------------------------------------------------------------------
tsoil_frq_sum = sum(tsoil_extrm_frq,3);
comp_frq_sum  = sum(comp_extrm_frq,3);

tsoil_extrm_frq_trd = zeros(size(tsoil_frq_sum));
tsoil_extrm_frq_trd_sig = zeros(size(tsoil_frq_sum));
comp_extrm_frq_trd  = zeros(size(comp_frq_sum));
comp_extrm_frq_trd_sig  = zeros(size(comp_frq_sum));

years   = [1980:2017]';
alpha   = 0.001;

for j = 1:length(lat)
    for i = 1:length(lon)
        if tsoil_frq_sum(i,j)~=0 % identify the grids with valid values
        b = Theil_Sen_Regress(years,squeeze(tsoil_extrm_frq(i,j,:)));      % linear trend based on Theil-Sen
        [H,p_value] = Mann_Kendall(squeeze(tsoil_extrm_frq(i,j,:)),alpha);   % significance test based on M-K
        tsoil_extrm_frq_trd(i,j) = b*10;
        tsoil_extrm_frq_trd_sig(i,j) = H;
        clear b H p_value
        else
        tsoil_extrm_frq_trd(i,j) = NaN;
        tsoil_extrm_frq_trd_sig(i,j) = NaN;
        end

        if comp_frq_sum(i,j)~=0 % identify the grids with valid values
        b = Theil_Sen_Regress(years,squeeze(comp_extrm_frq(i,j,:)));      % linear trend based on Theil-Sen
        [H,p_value] = Mann_Kendall(squeeze(comp_extrm_frq(i,j,:)),alpha);   % significance test based on M-K
        comp_extrm_frq_trd(i,j) = b*10;
        comp_extrm_frq_trd_sig(i,j) = H;
        clear b H p_value
        else
        comp_extrm_frq_trd(i,j) = NaN;
        comp_extrm_frq_trd_sig(i,j) = NaN;
        end
    end
    disp(j)
end
clear msoil tsoil 
clear msoil_extrm tsoil_extrm 
clear msoil_p10 tsoil_p90

lon2d = repmat(lon',[1 length(lat)]);
lat2d = repmat(lat,[length(lon) 1]);

lon1d = reshape(lon2d,[size(lon2d,1)*size(lon2d,2) 1]);
lat1d = reshape(lat2d,[size(lat2d,1)*size(lat2d,2) 1]);

load H:\WORKS\34-Soil_CDHE\figure2\chngon
stmp=s(2);
load H:\WORKS\34-Soil_CDHE\figure2\chnpatch
s(1).long=stmp.long;
s(1).lat=stmp.lat; 

[in1 on1] = inpolygon(lon1d,lat1d,s(1).long,s(1).lat);
[in2 on2] = inpolygon(lon1d,lat1d,s(2).long,s(2).lat);
[in3 on3] = inpolygon(lon1d,lat1d,s(3).long,s(3).lat);

in = in1|in2|in3|on1|on2|on3;

comp_extrm_frq_trd(find(in==0)) = NaN;
comp_extrm_frq_trd_sig(find(in==0)) = NaN;
%**************************************************************************
comp_extrm_frq_trd_sig = reshape(comp_extrm_frq_trd_sig,[size(comp_extrm_frq_trd_sig,1)*size(comp_extrm_frq_trd_sig,2) 1]);
lct = find(comp_extrm_frq_trd_sig==1);
lonsig = lon1d(lct);
latsig = lat1d(lct);
clear lct

comp_extrm_frq_trd2 = reshape(comp_extrm_frq_trd,[size(comp_extrm_frq_trd,1)*size(comp_extrm_frq_trd,2) 1]);
lct = find(isnan(comp_extrm_frq_trd2)==0);
weight  = cos(pi*lat1d(lct)/180.0);
weights = weight/mean(weight);

comp_frq_sum2 = reshape(comp_frq_sum,[size(comp_frq_sum,1)*size(comp_frq_sum,2) 1]);
comp_extrm_frq2 = reshape(comp_extrm_frq,[size(comp_extrm_frq,1)*size(comp_extrm_frq,2) size(comp_extrm_frq,3)]);
comp_extrm_frq2(find(in==0|comp_frq_sum2==0),:) = NaN;
comp_extrm_reg  = mean(comp_extrm_frq2(lct,:).*repmat(weights,[1 38]),1);

% b = Theil_Sen_Regress(years,comp_extrm_reg)
% datain = [years comp_extrm_reg'];
% [taub tau h sig Z S sigma sen n senplot CIlower CIupper D Dall C3 nsigma] = ktaub(datain, 0.05, 0)

s = RandStream('mlfg6331_64');
for i = 1:1000
sample = randsample(s,length(lct),length(lct),true);
weight2  = cos(pi*lat1d(lct(sample))/180.0);
weights2 = weight2/mean(weight2);
comp_extrm_reg_rand(:,i)  = mean(comp_extrm_frq2(lct(sample),:).*repmat(weights2,[1 38]),1)';
disp(i)
clear sample weight2 weights2
end

comp_extrm_frq_trd(find(isnan(comp_extrm_frq_trd)==1)) = -999;

comp_extrm_frq = reshape(comp_extrm_frq2,[length(lon) length(lat) 38]);
%--------------------------------------------------------------------------
comp_extrm = reshape(comp_extrm,[length(lon)*length(lat) 153 38]);
comp_extrm = double(comp_extrm);
comp_extrm(find(in==0|comp_frq_sum2==0),:,:) = NaN;

for y = 1:38
    lct_valid = find(sum(isnan(comp_extrm(:,:,y)),2)==0);
    comp_extrm_lct = comp_extrm(lct_valid,:,y);
    lct_valid2 = find(sum(comp_extrm_lct,2)>=3);
    comp_extrm_coverage(y) = 960*sum(weights(lct_valid2))/sum(weights);

    clear lct_valid lct_valid2 comp_extrm_lct
end

% b = Theil_Sen_Regress(years,comp_extrm_coverage)
% datain = [years comp_extrm_coverage'];
% [taub tau h sig Z S sigma sen n senplot CIlower CIupper D Dall C3 nsigma] = ktaub(datain, 0.05, 0)
%**************************************************************************
myncid = netcdf.create('fig2.nc', 'NC_NOCLOBBER');
dimid1 = netcdf.defDim(myncid,'lon',length(lon));
dimid2 = netcdf.defDim(myncid,'lat',length(lat));
dimid3 = netcdf.defDim(myncid,'sig',length(latsig));
dimid4 = netcdf.defDim(myncid,'years',38);
dimid5 = netcdf.defDim(myncid,'stat',2);
dimid6 = netcdf.defDim(myncid,'lct',length(lct));
varid1 = netcdf.defVar(myncid,'lon','double',dimid1);
varid2 = netcdf.defVar(myncid,'lat','double',dimid2);
varid3 = netcdf.defVar(myncid,'comp_extrm_frq_trd','double',[dimid1 dimid2]);
varid4 = netcdf.defVar(myncid,'lonsig','double',[dimid3]);
varid5 = netcdf.defVar(myncid,'latsig','double',[dimid3]);
varid6 = netcdf.defVar(myncid,'comp_extrm_reg','double',[dimid4]);
varid7 = netcdf.defVar(myncid,'comp_extrm_reg_stat','double',[dimid4 dimid5]);
varid8 = netcdf.defVar(myncid,'comp_extrm_frq','double',[dimid1 dimid2 dimid4]);
varid9 = netcdf.defVar(myncid,'lct','double',[dimid6]);
varid10 = netcdf.defVar(myncid,'weights','double',[dimid6]);
varid11 = netcdf.defVar(myncid,'comp_extrm_coverage','double',[dimid4]);
netcdf.endDef(myncid);
netcdf.putVar(myncid, varid1, lon);
netcdf.putVar(myncid, varid2, lat);
netcdf.putVar(myncid, varid3, comp_extrm_frq_trd);
netcdf.putVar(myncid, varid4, lonsig);
netcdf.putVar(myncid, varid5, latsig);
netcdf.putVar(myncid, varid6, comp_extrm_reg);
netcdf.putVar(myncid, varid7, [prctile(comp_extrm_reg_rand,5,2) prctile(comp_extrm_reg_rand,95,2)]);
netcdf.putVar(myncid, varid8, comp_extrm_frq);
netcdf.putVar(myncid, varid9, lct);
netcdf.putVar(myncid, varid10, weights);
netcdf.putVar(myncid, varid11, comp_extrm_coverage);
netcdf.reDef(myncid);
netcdf.putAtt(myncid, varid1,'units','degrees_north');
netcdf.putAtt(myncid, varid2,'units','degrees_east');
netcdf.close(myncid);